import numpy as np

if __name__ == '__main__':
    print(np.__version__)

    vector1 = np.array([1, 2, 3]);
    vector2 = np.array([4, 5, 6]);
    print(f"vector1: {vector1} + " f"vector2: {vector2} = {vector1 + vector2}")
    print(f"vector1: {vector1} - " f"vector2: {vector2} = {vector1 - vector2}")
    print(f"vector1: {vector1} * " f"vector2: {vector2} = {vector1 * vector2}")
    print(f"2 * vector1: {2 * vector1}")
    print(f"vector1: {vector1} * " f"dot(vector2): {vector2} = {vector1.dot(vector2)}")

    print(np.linalg.norm(vector1))
    print(np.linalg.norm(np.array([3,4])))
