import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler

# 归一化（Normalization）
def normal():
    x = [[1, 2], [0.5, 6], [0, 10], [1, 18]]
    # 得到归一化的缩放器对象
    scaler = MinMaxScaler(feature_range=(0, 1))
    x = scaler.fit_transform(x)
    print(x)

# 标准化（Standardization）
def standard():
    x = [[1, 2], [0.5, 6], [0, 10], [1, 18]]
    scaler = StandardScaler()
    x = scaler.fit_transform(x)
    print(x)


if __name__ == '__main__':
    print("归一化:")
    print(normal())
    print()

    print("标准化:")
    print(standard())
    print()
