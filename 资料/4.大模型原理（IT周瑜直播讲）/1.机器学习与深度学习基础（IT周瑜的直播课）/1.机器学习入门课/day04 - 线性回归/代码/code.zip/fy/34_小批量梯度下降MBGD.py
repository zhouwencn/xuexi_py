import matplotlib.pyplot as plt
import numpy as np


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def f(x):
    return x ** 2

# MBGD：小批量平均梯度（少量噪声）
def g_mbgd(x):
    grads = [2*x + np.random.normal(0, 0.1) for _ in range(10)]  # 10个样本为一批
    return np.mean(grads)  # 小批量：取平均梯度

x_list = []
y_list = []

# ========== 步骤1：初始化参数 ==========
x = -1
lr = 0.1

# ========== 步骤4：重复迭代 ==========
for i in range(100):
    y = f(x)
    x_list.append(x)
    y_list.append(y)

    # ========== 步骤2：计算梯度（一小批样本） ==========
    grad = g_mbgd(x)  # MBGD：小批量平均梯度
    # ========== 步骤3：更新参数 ==========
    x = x - lr * grad

print("MBGD 最终x：", x)

x_plot = np.arange(-1.2, 1.2, 0.01)
plt.plot(x_plot, f(x_plot))
plt.plot(x_list, y_list, 'b')
plt.scatter(x_list, y_list, c='b')
plt.title("MBGD 小批量梯度下降（平稳又快，最常用）")

plt.show()