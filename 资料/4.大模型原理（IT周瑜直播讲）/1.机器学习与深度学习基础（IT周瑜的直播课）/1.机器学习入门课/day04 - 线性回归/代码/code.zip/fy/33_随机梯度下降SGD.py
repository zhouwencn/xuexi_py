import matplotlib.pyplot as plt
import numpy as np

'''
随机梯度下降 SGD

目标函数：y=x^2
起点：x=−1
学习率：0.1
迭代 100 次

每次只算 1 个随机样本的梯度！路线会抖动！
'''

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False



def f(x):
    return x ** 2

# SGD：梯度加一点随机噪声（模拟只用1个样本算梯度）
def g_sgd(x):
    return 2 * x + np.random.normal(0, 0.4)  # 随机噪声 = SGD抖动来源

x_list = []
y_list = []

# ========== 步骤1：初始化参数 ==========
x = -1
lr = 0.1

# ========== 步骤4：重复迭代 ==========
for i in range(100):
    y = f(x)
    x_list.append(x)
    y_list.append(y)

    # ========== 步骤2：计算梯度（随机1个样本） ==========
    grad = g_sgd(x)  # SGD：随机梯度，会晃

    # ========== 步骤3：更新参数 ==========
    x = x - lr * grad

print("SGD 最终x：", x)

x_plot = np.arange(-1.2, 1.2, 0.01)
plt.plot(x_plot, f(x_plot))
plt.plot(x_list, y_list, 'g')
plt.scatter(x_list, y_list, c='g')
plt.title("SGD 随机梯度下降（抖动大、快）")

plt.show()