import pandas as pd # 导入数据处理库
from sklearn.model_selection import train_test_split # 导入数据集划分工具
from sklearn.preprocessing import StandardScaler, OneHotEncoder # 导入标准化、独热编码工具
from sklearn.compose import ColumnTransformer # 列转换器：对不同列做不同处理
from sklearn.linear_model import LogisticRegression # 逻辑回归模型

# ===================== 1. 加载外部csv数据 =====================
# 读取CSV文件
dataset = pd.read_csv('../data/heart_disease.csv')
# 删除缺失值（空数据）
dataset.dropna(inplace=True)
# 查看数据信息：行数、列数、类型、缺失值
dataset.info()
# 查看前5行数据
print(dataset.head())

# ===================== 2. 划分特征与标签 / 训练集测试集 =====================
# X：所有特征（去掉标签列）axis=1表示删除 列名为 “是否患有心脏病” 的那一列，剩下的全部是输入特征
X = dataset.drop('是否患有心脏病', axis=1)
# y：标签（目标：是否患心脏病 0/1）
y = dataset['是否患有心脏病']

# 输出数据形状 (样本,特征)
print(X.shape)  # (1025, 13) → 1025样本 × 13特征
print(y.shape)  # (1025,)    → 1025标签

# train_test_split：把数据分成训练集、测试集
# 训练集（70%）：教模型学习规律
# 测试集（30%）：模拟新数据，评估模型效果
# random_state=42：固定随机种子，保证结果可复现
x_train, x_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)
# 打印训练/测试集形状
print(x_train.shape, x_test.shape)  # (717,13) (308,13) 70%训练，30%测试

# ===================== 3. 特征工程 =====================
# 数值型特征（6 个）：标准化，把所有数值缩放到均值 0，方差 1
numerical_features = ["年龄", "静息血压", "胆固醇", "最大心率", "运动后的ST下降", "主血管数量"]
# 类别型特征（4 个）：需要独热编码(独热编码怎么把 4 列变成 10 列,后续给同学们讲解清楚)
categorical_features = ["胸痛类型", "静息心电图结果", "峰值ST段的斜率", "地中海贫血"]
# 二元特征（3 个）：0/1，不需要处理
binary_features = ["性别", "空腹血糖", "运动性心绞痛"]

# 列转换器：不同列做不同预处理
ct = ColumnTransformer(
    transformers=[
        # 数值特征 → StandardScaler标准化，把所有数值缩放到均值 0，方差 1
        ('std', StandardScaler(), numerical_features),
        # 分类特征 →  OneHotEncoder 独热编码，drop='first'防止多重共线性
        ('cat', OneHotEncoder(drop='first'), categorical_features),
        # 二元特征 → 不处理，直接通过
        ('bin', 'passthrough', binary_features),
    ]
)

# 训练集：fit + transform
x_train = ct.fit_transform(x_train)
# 测试集：只transform（不能fit！）
x_test = ct.transform(x_test)

# 预处理后特征从13个 → 19个（因为独热编码扩展了特征，4 个分类特征，从 4 列变成了 10 列，多了 6 列）
print(x_train.shape, x_test.shape)  # (717, 19) (308, 19)

# ===================== 4. 模型训练与评估 =====================
# 逻辑回归，迭代次数1000（保证收敛）
model = LogisticRegression(max_iter=1000)
# 训练模型
model.fit(x_train, y_train)
# 测试集评估准确率
acc = model.score(x_test, y_test)
print("准确率(预测正确的数量➗总数量)：", acc)  # 0.818 → 81.8%
print()
print("机器学习二分类项目流程，案例小总结：\n"
      "1. 读取数据 → 2. 数据清洗 → 3. 划分数据集 → 4. 特征工程 → 5. 训练模型 → 6. 评估最终准确率 81.8%，效果良好。");



'''
 预处理后特征从13个 → 19个（因为独热编码扩展了特征，4个分类特征，从 4 列变成了 10 列，多了 6 列）
┌───────────────────────────────────────┐
│ ② 分类特征：4个　　★核心变化在这里★　│
│ 胸痛类型、心电结果、ST斜率、地中海贫血
└───────────────────────────────────────┘
          ↓（OneHot + drop='first'）
        变成：**10列**
           胸痛类型(4类→3列)
           心电结果(3类→2列)
           ST斜率(3类→2列)
           地中海贫血(4类→3列)
           3+2+2+3 = **10**
'''