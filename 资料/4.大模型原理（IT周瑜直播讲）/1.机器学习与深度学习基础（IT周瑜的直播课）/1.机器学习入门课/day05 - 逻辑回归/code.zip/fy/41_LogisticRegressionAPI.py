# 从 sklearn 线性模型库 导入 逻辑回归算法库LogisticRegression
from sklearn.linear_model import LogisticRegression

'''
LogisticRegression相关API简介，日常逻辑回归可以用它
    是一个带L1（Lasso正则）正则、自动平衡类别、支持多分类、适合大数据的稳定逻辑回归模型。

适合什么任务
    多分类问题
    特征很多、需要特征选择
    样本不平衡
    希望模型简单、稳定、不过拟合

日后工作怎么用，常见搭配公式（直接背）
1 标准二分类（最常用）
LogisticRegression(class_weight='balanced', max_iter=1000)
    
2 带 L1 正则 + 特征选择（必须用 saga）
LogisticRegression(penalty='l1', solver='saga', C=0.5, max_iter=1000)

3 多分类任务
LogisticRegression(multi_class='multinomial', solver='saga', max_iter=1000)
'''

# 创建逻辑回归模型对象，类似java程序new一个对象（这是最常用、最稳定的默认组合）
# 这是 工业界最标准、最通用、最稳定 的逻辑回归配置：
# 求解器稳定（lbfgs）
# 防止过拟合（l2 + C=1）
# 自动处理不平衡数据（balanced)   → 几乎适用于 90% 的分类任务！
model = LogisticRegression(
    solver="lbfgs",        # 优化器：求最优解的方法,作用：模型用什么方法 “找最优答案”
    penalty="l2",          # 正则化类型：L2正则化让模型不钻牛角尖，泛化能力更强，防止模型过拟合(让权重不要太大,不会把权重变成零，只会缩小权重)
    C=1,                   # 正则化强度：C=1是默认值代表标准强度，C越小正则越强，平衡模型复杂度，不太过拟合，也不太欠拟合
    class_weight="balanced", # 自动处理样本不平衡（按类别数量加权），让模型不偏向数量多的类别，balanced 会自动加权，让少的类别也被重视
    max_iter=1000,            # 最大迭代次数（保证模型收敛），默认只有 100，经常不收敛(模型还没找到最优答案，训练提前被逼停了)，设为 1000 保证模型一定能训练完成
    multi_class="multinomial" # 多分类模式：直接支持多类别分类,输出属于每一类的概率。不是 “一对多”，适合 3 类及以上分类任务
)

'''
逻辑回归 (LogisticRegression) 完整参数速查表
见阳哥脑图笔记
'''