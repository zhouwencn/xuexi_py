def estimate_tokens(text: str) -> int:
    """
    简易 Token 估算函数（无需依赖外部库如 tiktoken）

    估算规则：
    1. 中文字符：通常占比较多 token，按 1.5 个字符对应 1 个 token 估算
    2. 其他字符（英文、数字、标点）：按 4 个字符对应 1 个 token 估算

    Args:
        text (str): 需要估算的文本字符串

    Returns:
        int: 估算出的 token 总数
    """
    # 统计中文字符数量（利用 Unicode 范围：\u4e00-\u9fff）
    chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')

    # 计算非中文字符数量
    other_chars = len(text) - chinese_chars

    # 根据加权比例计算总 token 数并取整
    return int(chinese_chars / 1.5 + other_chars / 4)

def select_chunks_within_budget(chunks: list[dict],
                                max_tokens: int = 3000) -> list[dict]:
    """
    在指定的 Token 预算内，采用贪心策略从检索结果中筛选文本片段 (Chunks)

    策略说明：
    1. 假设输入 chunks 已按相关性（如相似度得分）降序排列
    2. 遍历 chunks 并累加 token 数，一旦超过 max_tokens 预算即停止
    3. 确保在上下文长度限制内，优先保留最相关的片段

    Args:
        chunks (list[dict]): 包含文本片段的字典列表，每个字典需含有 "content" 键
        max_tokens (int): 允许的最大 token 预算，默认为 3000

    Returns:
        list[dict]: 筛选后符合预算要求的文本片段列表
    """
    selected = []
    total_tokens = 0

    for chunk in chunks:
        # 估算当前片段的 token 消耗； 1000；  879
        chunk_tokens = estimate_tokens(chunk["content"])

        # 检查加入当前片段后是否会超出总预算
        if total_tokens + chunk_tokens > max_tokens:
            # 若超出则停止筛选，确保不突破上下文窗口
            break

        # 将片段加入已选列表并更新总 token 计数
        selected.append(chunk)
        total_tokens += chunk_tokens

    return selected