# 加载各种文档： pdf，docx，txt，html，md，
from pypdf import PdfReader
import os
## 定义一个方法，能加载各种文档，返回 {"content": 文本内容, "metadata": 来源信息}
def load_document(document_path: str) -> dict:
    """
      加载各种文档，返回 {"content": 文本内容, "metadata": 来源信息}

      document_path: 文档路径 \n
      return dict: {"content": 文本内容, "metadata": 来源信息}
         """
    ext = os.path.splitext(document_path)[1].lower()

    ## 1. 优化点：无限扩展 支持更多文件格式； 数据抽取方式。
    ## 2. 优化点：内容的识别度要高，格式准确。 如果不准确需要引入数据清洗模块
    ## 3. 优化点： pdf中的图片没办法识别。 如果pdf是扫描件。
    #             引入 vl视觉模型 或者 ocr模型（deepseek-ocr、paddleocr等）；

    ## ETL 流程： Extra（抽取）、Transform（转换）、Load（加载/向量化存到向量库中）
    ## 扩展名 对应的加载函数 规则表
    loaders = {".txt": load_txt, ".md": load_txt, ".pdf": load_pdf}


    loader = loaders.get(ext)
    if not loader:
        raise ValueError(f"不支持的文件格式: {ext}（当前支持：.txt .md .pdf）")
    return loader(document_path)



## 通用的读取办法
def load_txt(file_path: str) -> dict:
    """加载 TXT / Markdown 文件，统一编码为 utf-8"""

    # 根据 path 获取文件名
    file_name = os.path.basename(file_path)

    with open(file_path, 'r', encoding='utf-8') as f:
        return {
            "content": f.read(),
            "metadata": {"source": file_path, "type": "txt", "name": file_name}
        }


def load_pdf(file_path: str) -> dict:
    """加载 PDF 文件：逐页提取文本，用换行符拼接各页内容"""

    # 根据 path 获取文件名
    file_name = os.path.basename(file_path)
    # 读取pdf内容
    reader = PdfReader(file_path)
    # extract_text 提取文本内容； 扫描件pdf，返回空串
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    return {
        "content": text,
        "metadata": {"source": file_path, "type": "pdf", "pages": len(reader.pages), "name": file_name}
    }


def test_load_document(document_path: str) -> dict:
    dict = load_document(document_path)
    print(f"加载文档: {document_path} 成功，\n 内容: {dict['content']}... \n 元数据: {dict['metadata']}")

# test_load_document("../测试物料/python_faq.txt")
test_load_document("../测试物料/员工假期管理制度.pdf")
# test_load_document("../测试物料/辰光Agent平台说明书.md")