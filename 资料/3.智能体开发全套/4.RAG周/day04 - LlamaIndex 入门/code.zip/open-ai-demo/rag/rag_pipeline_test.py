from document_load_api import load_document
from rag.query_rag import rag_query
from text_spliter_api import split_text
from embedding_api import get_embedding_batch,client
from vector_store import build_faiss_index,save_index,load_index

# 1. 构建数据
def init_data():
    ## 1. 得到文档内容
    document = load_document("../测试物料/员工假期管理制度.pdf")
    ## 2. 对文档内容进行分块
    chunks = split_text(document["content"])

    texts = [c["content"] for c in chunks]

    ## 3. 对所有 chunks 批量向量化（一次 API 调用，比循环逐个调用快得多）
    embeddings = get_embedding_batch(texts, "text-embedding-v3",client)

    ## 4. 构建索引并持久化
    index = build_faiss_index(embeddings)

    ## 5. 保存索引和元数据
    save_index(index, chunks, "../faiss_data/rag.index", "../faiss_data/rag_chunks.json")
    return index, chunks


def test_rag_query():
    index, chunks = init_data()
    # 请确认模型名称为当前可用版本（查询日期：2026-02）
    EMBED_MODEL = "text-embedding-v3"   # Qwen Embedding，仍有效；可选升级 text-embedding-v4
    CHAT_MODEL  = "qwen3.5-plus"           # 或 "gpt-5-mini"（GPT-5 家族的轻量变体，更低成本），支持 OpenAI 协议的模型均可

    test_queries = [
        "年假可以申请几天？",                        # 知识库内有答案（PDF）
        "年假的申请流程是什么？",                     # 换一种措辞提问，测试语义检索（PDF）
        "量子纠缠是什么？",                          # 故意超出知识库范围，测试兜底逻辑
    ]

    for q in test_queries:
        print(f"\n{'='*60}")
        print(f"❓ 问题：{q}")
        result = rag_query(q, client, EMBED_MODEL, CHAT_MODEL, index, chunks)

        print(f"✅ 回答：\n{result['answer']}")
        print(f"\n📚 引用来源（检索到 {result['total_retrieved']} 条，实际使用 {len(result['sources'])} 条）：")
        for src in result["sources"]:
            print(f"   - {src['metadata'].get('source')} (score={src['score']:.4f})")

test_rag_query()