# 系统提示词
SYSTEM_PROMPT = """你是一个专业的知识库问答助手。请严格基于【参考资料】中的内容回答用户问题。

规则：
1. 只使用参考资料中的信息回答，不要编造内容
2. 如果参考资料中没有相关信息，请明确说"根据现有资料，我无法回答这个问题"
3. 回答时尽量引用原文关键语句，并在括号中标注来源文件名
"""

def build_rag_prompt(query: str, retrieved_chunks: list[dict]) -> list[dict]:
    """
    构建 RAG 增强后的消息列表（供 chat.completions.create 使用）
    返回标准的 OpenAI messages
    """


    # 和大模型聊天， 把用户问题，检索到的内容，系统提示词，都放在一起
    if not retrieved_chunks:
        # 兜底：没有检索结果时，直接告知无相关资料
        context = "（当前知识库中未找到与该问题相关的资料）"
    else:
        # 提取并格式化检索到的知识片段
        context_parts = []

        for i, chunk in enumerate(retrieved_chunks):
            # 获取来源元数据，若不存在则显示“未知来源”
            source = chunk["metadata"].get("name", "未知来源")

            # 从文件路径中提取文件名（处理跨平台路径分隔符）

            # 组合编号、来源和具体内容
            context_parts.append(f"【资料{i + 1}】（来源：{source}）\n{chunk['content']}")

        # 将多个资料片段用换行符连接成完整的上下文字符串
        context = "\n\n".join(context_parts)


    user_content = f"""
        【参考资料】
        {context}

        【用户问题】
        {query}"""

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content}
    ]

