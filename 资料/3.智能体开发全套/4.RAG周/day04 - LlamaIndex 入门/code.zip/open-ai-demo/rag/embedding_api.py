from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

api_key = os.getenv("API_KEY")
base_url = os.getenv("BASE_URL_CHAT")

from openai import OpenAI

client = OpenAI(
    api_key=api_key,
    base_url=base_url,
)

# 把 文本转换为向量
def get_embedding(text: str,model: str, client: OpenAI) -> list[float]:
    """
    把 文本转换为向量
    """

    # 给 embedding 模型 发起请求，把 文本 转换为 向量
    response = client.embeddings.create(
        model=model,
        input=text
    )


    return response.data[0].embedding


def get_embedding_batch(text: list[str],model: str, client: OpenAI) -> list[list[float]]:
    """
    把 文本转换为向量
    """

    # 给 embedding 模型 发起请求，把 文本 转换为 向量
    response = client.embeddings.create(
        model=model,
        input=text
    )

    # 提取向量
    return [item.embedding for item in response.data]



## 测试
def test_embedding():


    # 获取向量内容；
    # embedding = get_embedding("你好","text-embedding-v3",client)
    text = ["你好","你好吗","你好吗？"]
    embeddings = get_embedding_batch(text,"text-embedding-v3",client)
    for txt,embedding in zip(text,embeddings):
        print(f"内容：{txt} 向量维度: {len(embedding)} 向量内容: {embedding[:10]}\n")





# test_embedding()

