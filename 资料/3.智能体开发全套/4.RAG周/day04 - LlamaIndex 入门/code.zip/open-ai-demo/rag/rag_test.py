from dotenv import load_dotenv
import os
from query_rag import search
from rag.rag_prompt import build_rag_prompt
from vector_store import load_index
from token_limit import select_chunks_within_budget


load_dotenv()

api_key = os.getenv("API_KEY")
base_url = os.getenv("BASE_URL_CHAT")

from openai import OpenAI

client = OpenAI(
    api_key=api_key,
    base_url=base_url,
)

# 加载向量索引； Milvus 连接。
index, chunks = load_index("../faiss_data/faiss_index.idx",
                           "../faiss_data/faiss_metadata.json")
# 4096 k;    128k
query = "年假可以申请几天？"

results = search(
    query,          # 查询文本
    client,    # 嵌入模型客户端
    "text-embedding-v3",          # 嵌入模型名称
    index,          # 向量索引
    chunks,         # 原始文本块
    top_k=5,        # 返回最相关的结果数量
    threshold=0.5   # 相似度阈值
)

print(f"检索到 {len(results)} 条相关结果")
for i, r in enumerate(results):
    # map.get("key")
    source = r['metadata'].get('source', '未知')
    print(f"\n── Top {i+1}（得分 {r['score']:.4f}，来源：{source}）")
    print(r["content"][:150] + "...")

print("="*50)


### token 限制； 对所有结果 加上token限制
selected = select_chunks_within_budget(results,max_tokens=300)

# 拼装提示词
messages = build_rag_prompt(query, selected)


# 调用大模型进行回复; 给大模型要发内容
response = client.chat.completions.create(
    messages=messages,
    model="qwen3.5-plus",
)

print(response.choices[0].message.content)
