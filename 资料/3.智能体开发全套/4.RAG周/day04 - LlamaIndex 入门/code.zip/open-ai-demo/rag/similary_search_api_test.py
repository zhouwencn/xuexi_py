import numpy as np
from embedding_api import get_embedding


def cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    """
    计算两个向量之间的余弦相似度（NumPy 实现）

    Args:
        vec_a: 向量 A 的数值列表
        vec_b: 向量 B 的数值列表

    Returns:
        float: 余弦相似度得分，取值范围为 [-1, 1]，越接近 1 表示越相似
    """
    # 将输入列表转换为 NumPy 数组以便进行向量化计算
    a, b = np.array(vec_a), np.array(vec_b)

    # 计算向量点积 (Dot Product): A · B
    dot_product = np.dot(a, b)

    # 计算向量的 L2 范数 (模长): ||A|| 和 ||B||
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)

    # 根据公式计算余弦相似度: cos(θ) = (A · B) / (||A|| * ||B||)
    # 注意：实际应用中应考虑分母为 0 的情况
    return float(dot_product / (norm_a * norm_b))



from dotenv import load_dotenv
import os


load_dotenv()

api_key = os.getenv("API_KEY")
base_url = os.getenv("BASE_URL_CHAT")

from openai import OpenAI

client = OpenAI(
    api_key=api_key,
    base_url=base_url,
)
MODEL = "text-embedding-v3"

pairs = [
    ("如何申请年假", "请假流程是什么"),  # 中文同义，语义相近
    ("如何申请年假", "今天天气怎么样"),  # 语义无关
    ("Python 列表排序", "Python list sort"),  # 中英文同义
]

for text_a, text_b in pairs:
    # 调用 Embedding 接口获取文本 A 的向量表示
    vec_a = get_embedding(text_a, MODEL, client)
    # 调用 Embedding 接口获取文本 B 的向量表示
    vec_b = get_embedding(text_b, MODEL, client)

    # 计算两个向量之间的余弦相似度（Score 越接近 1 表示语义越相关）
    score = cosine_similarity(vec_a, vec_b)

    # 打印对比结果，展示不同文本组合下的语义匹配得分
    print(f"  {text_a!r:20s} vs {text_b!r:20s}  →  {score:.4f}")