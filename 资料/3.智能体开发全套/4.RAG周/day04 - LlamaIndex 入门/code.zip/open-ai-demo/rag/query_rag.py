import faiss

from rag.embedding_api import get_embedding
import numpy as np

from rag.rag_prompt import build_rag_prompt
from rag.token_limit import select_chunks_within_budget


def search(query: str, client, model: str, index: faiss.IndexFlatIP,
           chunks: list[dict], top_k: int = 5,
           threshold: float = 0.5) -> list[dict]:
    """
    RAG 检索函数：向量化查询 → FAISS 检索 → 相似度过滤 → 排序
    参数：
      threshold: 余弦相似度阈值（0~1），低于此分数的结果被丢弃
    返回：
      按相似度降序排列的 chunk 列表，每项含 content / metadata / score
    """

    # Step 1: 查询向量化 + 归一化（必须与索引构建时用同一模型和同样的归一化）
    query_vec = np.array([get_embedding(query, model, client)], dtype=np.float32)
    # 归一化查询向量
    faiss.normalize_L2(query_vec)

    # Step 2: FAISS 检索
    scores, indices = index.search(query_vec,top_k)

    # Step 3: 过滤相似度低于阈值的结果
    # Step 3: 过滤 + 组装输出
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:  # FAISS 填充的无效位置（top_k > 实际向量数时出现）
            continue
        if score < threshold:  # 相似度低于阈值，丢弃
            continue
        results.append({
            "content": chunks[idx]["content"],
            "metadata": chunks[idx]["metadata"],
            "score": float(score)
        })

    # Step 4: 按相似度降序排序（FAISS 已返回排序结果，此处为显式保证）
    results.sort(key=lambda x: x["score"], reverse=True)


    return results


def rag_query(query: str,
              client,
              embed_model: str,
              chat_model: str,
              index: faiss.IndexFlatIP,
              chunks: list[dict],
              top_k: int = 5,
              max_context_tokens: int = 3000) -> dict:
    """
    完整 RAG Pipeline：提问 → 检索 → Prompt → LLM 生成
    返回：{
      "answer":          str,       # LLM 生成的回答
      "sources":         list[dict], # 实际使用的 chunk 列表
      "total_retrieved": int         # 检索到的候选总数
    }
    """
    # Step 1: 检索相关片段
    results = search(query, client, embed_model, index, chunks, top_k=top_k)

    # Step 2: Token 预算控制
    selected = select_chunks_within_budget(results, max_tokens=max_context_tokens)

    # Step 3: 构建增强 Prompt
    messages = build_rag_prompt(query, selected)

    # Step 3: 调用 LLM 生成回答
    response = client.chat.completions.create(
        model=chat_model,
        messages=messages
    )
    answer = response.choices[0].message.content

    return {
        "answer": answer,
        "sources": results,
        "total_retrieved": len(results)
    }




