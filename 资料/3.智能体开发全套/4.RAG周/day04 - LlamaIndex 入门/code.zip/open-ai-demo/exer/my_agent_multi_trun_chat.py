from advanced.create_client import client

# 自定义多轮回话，实现记忆功能。 用户退出回话之前，模型永远记住用户的聊天历史
## 1）、临时用户：推荐 保存到 redis 的 list 数据结构中。
## 2）、长期用户：推荐 保存到数据库中。 聊天历史的查询是数据库来实现的。
## list 中每一个消息是： {"role": "user", "content": "我是雷丰阳，请记住我的名字"}； 注意区分 role 类型即可
# 如何解决 messages 回话列表 太浪费 token 的问题；
### 思路：每 20 轮回话，对所有message消息做一个 总结（压缩技术）。 然后将总结添加到 messages 中（系统提示词）。
### 每 N 轮总结 (让大模型) 出新系统提示词。


# 维护回话
messages = []
turn_count = 1

while True:
    print(f" ================== 第 {turn_count} 轮回话开始 ==================")
    user_input = input("请输入：")

    if user_input == "exit":
        break

    # 调用模型
    messages.append({"role": "user", "content": user_input})
    response = client.responses.create(
        input=messages,
        model="qwen3.5:4b"
    )

    # 流式API的输出
    print("\n")
    print(f" ================== 模型响应 ==================")
    turn_count += 1
    print(response.output_text)

    # 维护回话列表
    messages.append({"role": "assistant", "content": response.output_text})







