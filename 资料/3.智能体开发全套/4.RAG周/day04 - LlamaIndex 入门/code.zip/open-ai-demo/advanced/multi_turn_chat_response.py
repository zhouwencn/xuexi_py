from  create_client import client


# 多轮回话，如何让模型记住上一次的对话内容，例如记住用户的名字；
# 上下文；


# 模型默认没有记忆
## 新版 responses api： 只需要传入：previous_response_id 即可实现记忆功能；
### 注意：云厂商默认就是实现了这个功能。 如果是调用本地模型，需要手动实现记忆功能。



response = client.responses.create(
    input="我是雷丰阳，请记住我的名字",
    model="qwen3.5:4b"
)
print(f"模型第1次响应：{response.output_text}")


# response2 = client.responses.create(
#     input="西游记里面有哪些主角",
#     model="qwen3.5:9b",
#     previous_response_id=response.id
# )
# print(f"模型第2次响应：{response2.output_text}")

response3 = client.responses.create(
    input="你知道我叫什么名字吗？",
    model="qwen3.5:4b",
    previous_response_id=response.id
)
print(f"模型第3次响应：{response3.output_text}")