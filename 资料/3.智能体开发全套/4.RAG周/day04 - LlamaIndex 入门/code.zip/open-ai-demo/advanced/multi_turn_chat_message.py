from  create_client import client

messages = [{"role": "user", "content": "我是雷丰阳，请记住我的名字"}]

## 实现多轮回话记忆，两种方式
### 1）、构建messages列表； 缺点：1. 需要手动构建，比较麻烦。  2. 特别浪费token   3. 很快就达到模型的最大token数。
### 2）、串联response.id： 缺点： 1. 需要自己写实现。  2. 维护整合回话历史缓存
response = client.responses.create(
    input=messages,
    model="qwen3.5:4b"
)

print(f"模型第1次响应：{response.output_text}")

# 拿到模型的响应，
msg = {"role": "assistant", "content": response.output_text}

# 添加到 messages 列表中. 构建出整个对话历史
messages.append(msg)

# 用户的第二个问题
messages.append({"role": "user", "content": "你知道我叫什么名字吗？"})
response2 = client.responses.create(
    input=messages,
    model="qwen3.5:4b"
)

print(f"模型第2次响应：{response2.output_text}")
