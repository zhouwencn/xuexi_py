from advanced.create_client import client

response = client.responses.create(
    model="qwen3.5-plus",
    input="帮我找一下阿里云官网，并提取首页的关键信息",
    # 建议同时开启内置工具以取得最佳效果； 我们无需干涉，大模型自动调用。 这个是云厂商实现的功能
    tools=[
        {"type": "web_search"},  # 内部工具
        {"type": "code_interpreter"}, # 内部工具
        {"type": "web_extractor"} # 内部工具
    ],
    extra_body={"enable_thinking": True}
)

# 取消以下注释查看中间过程输出
print(response.output)
# print(response.output_text)