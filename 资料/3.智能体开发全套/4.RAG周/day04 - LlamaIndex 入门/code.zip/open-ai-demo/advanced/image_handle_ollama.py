from advanced.create_client import client


## 把图片转换为 base64 编码的字符串
import base64

def  encode_base64(url: str):
    ## 加载图片数据流。
    with open(url, "rb") as image_file:
        image_data = image_file.read()
        ## 编码为 base64 字符串
        base64_str = base64.b64encode(image_data).decode("utf-8")
        return base64_str


## 本地模型不支持 图片地址的方式。需要  base64 encoded data instead

base64 = encode_base64("dog_and_girl.jpeg")
completion = client.chat.completions.create(
    model="qwen3-vl:4b", # 此处以qwen3.5-plus为例，可按需更换模型名称。模型列表：https://help.aliyun.com/zh/model-studio/models
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{base64}"
                    },
                },
                {"type": "text", "text": "图中描绘的是什么景象?"},
            ],
        },
    ],
)


print(completion.choices[0].message.content)