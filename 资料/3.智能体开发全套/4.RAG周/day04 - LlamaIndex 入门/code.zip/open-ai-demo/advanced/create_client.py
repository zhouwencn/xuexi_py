import httpx
from dotenv import load_dotenv
import os


load_dotenv()

api_key = os.getenv("API_KEY")
base_url = os.getenv("BASE_URL")


from openai import OpenAI


# 关键：创建走 ProxyPin 的 HTTP 客户端
proxy = "http://127.0.0.1:9099"  # ProxyPin 默认地址
http_client = httpx.Client(proxy=proxy, verify=False)

client = OpenAI(
    base_url=base_url,
    api_key=api_key,
    http_client=http_client
)