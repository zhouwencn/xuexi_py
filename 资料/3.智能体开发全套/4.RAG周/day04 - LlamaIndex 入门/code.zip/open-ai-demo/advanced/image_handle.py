from advanced.create_client import client


# 实现 图像识别；  多模态模型；
## 视觉模型： qwen-vl（视觉模型）、 qwen3.5-plus（视觉模型）；  图片理解

## 视觉模型还会用来做 OCR（光学字符识别，将图片中的文字识别出来文本化）
## 我们问诊系统对接多模态，实现图片识别？ 使用视觉模型；
### 云端模型会自己拿到 url 中的图片字节。 然后进行识别；
completion = client.chat.completions.create(
    model="qwen3.5-plus", # 此处以qwen3.5-plus为例，可按需更换模型名称。模型列表：https://help.aliyun.com/zh/model-studio/models
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://help-static-aliyun-doc.aliyuncs.com/file-manage-files/zh-CN/20241022/emyrja/dog_and_girl.jpeg"
                    },
                },
                {"type": "text", "text": "图中描绘的是什么景象?"},
            ],
        },
    ],
)


print(completion.choices[0].message.content)