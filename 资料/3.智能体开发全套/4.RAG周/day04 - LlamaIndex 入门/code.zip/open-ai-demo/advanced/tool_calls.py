import json
import random

from advanced.create_client import client

## 此次使用 本地测试


# 模拟用户问题
USER_QUESTION = "北京天气咋样"

# 必须把我们系统中的所有工具的定义（Tool Definition）都传递给大模型； 让大模型知道有哪些工具可以调用，实现什么功能
tools = [
    {
        "type": "function",  # 这是一个函数工具
        "name": "get_current_weather",  # 工具的名称，用于调用时引用
        "description": "当你想查询指定城市的天气时非常有用。", # 工具的描述，用于提示大模型
        "parameters": {  # 工具的参数定义，用于提示大模型
            "type": "object", # 工具的参数是一个对象
            "properties": {
                "location": {  # 工具的参数 location 是一个字符串，用于指定要查询的天气的城市或县区
                    "type": "string",
                    "description": "城市或县区，比如北京市、杭州市、余杭区等。",
                }
            },
            "required": ["location"], # 工具的参数 location 是必填项
        },
    }
]

# 模拟天气查询工具
def get_current_weather(args):
    weather_conditions = ["晴天", "多云", "雨天"]
    random_weather = random.choice(weather_conditions)
    location = args["location"]
    return f"{location} 今天是 {random_weather}。"

# 封装模型响应函数
def get_response(msg):
    response = client.responses.create(
        model="qwen3.5:9b",  # 可选：qwen3.5-flash、qwen3.5-flash-2026-02-23
        input=msg,
        tools=tools,
    )
    return response


# 维护对话上下文
messages = [{"role": "user", "content": USER_QUESTION}]

##
print(" =========== 第一次调用模型 =========== \n")
response = get_response(messages)
# 大模型响应数据的 output 数组里面可能有 很多元素。 如果 type 是 function_call 说明是函数调用，

print(" =========== 第一次模型返回结果 =========== \n")
function_calls = [item for item in response.output if item.type == "function_call"]

print("需要调用的函数：", function_calls)

response = None;
## 这些就是 langchain 工具调用的底层逻辑
## 自己去调用对应的工具，获取工具的返回值
while function_calls:
    for function_call in function_calls:
        args = json.loads(function_call.arguments)
        name = function_call.name
        print(f"准备调用函数 {name}，参数为 {args}")
        ## 自己写工具调用逻辑。动态查找对应的工具函数 ，并调用它
        result = get_current_weather(args)
        print(f"函数 {name} 返回结果：{result}")

        ## 把工具调用信息，添加上下文，告诉大模型把这个工具调用了
        messages.append({
            "type": "function_call",
            "name": name,
            "arguments": function_call.arguments,
            "call_id": function_call.call_id
        })

        ## 把调用结果，添加到对话上下文
        messages.append({
            "type": "function_call_output",
            "call_id": function_call.call_id,
            "output": result,
        })

    ## 工具调用完全结束，并拼装号了给模型的回复
    print(" =========== 第二次调用模型（携带了用户自己对工具调用的信息及结果） =========== \n")
    response = get_response(messages)
    print(" =========== 第二次模型返回结果 =========== \n")
    function_calls = [item for item in response.output if item.type == "function_call"]

print(f"模型最终回复：{response.output_text}")
