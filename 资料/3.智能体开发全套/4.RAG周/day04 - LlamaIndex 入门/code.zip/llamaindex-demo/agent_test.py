from llama_index.llms.ollama import Ollama
from llama_index.core.agent.workflow import FunctionAgent

## 定义工具
def multiply(a: float, b: float) -> float:
    """Multiply two numbers and returns the product"""
    print(f"{a} * {b} = {a*b}")
    return a * b


def add(a: float, b: float) -> float:
    """Add two numbers and returns the sum"""
    print(f"{a} + {b} = {a+b}")
    return a + b


## 初始化 llm
llm=Ollama(model="qwen3.5:4b")


## 初始化智能体
workflow = FunctionAgent(
    tools=[multiply, add],
    llm=llm,
    system_prompt="You are an agent that can perform basic mathematical operations using tools.",
)

## 运行智能体（异步模式）
async def main():
    response = await workflow.run(user_msg="What is 20+(2*4)?")
    print(response)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())