# 以前函数调用：
# 发所有函数的说明json + 大模型决定调用哪个函数 + 用户收到大模型的决定，自己调用函数 + 函数返回结果发给大模型 + 大模型返回


from llama_index.core.tools import FunctionTool
from llama_index.llms.ollama import Ollama

def generate_song(name: str, artist: str) -> dict:
    """Generates a song with provided name and artist."""
    return {"name": name, "artist": artist}


# 指定有一个函数
tool = FunctionTool.from_defaults(fn=generate_song)


llm = Ollama(model="qwen3.5:4b",request_timeout=500)

# 传入函数列表
response = llm.predict_and_call(
    [tool],
    "Pick a random song for me",
)

print(str(response))