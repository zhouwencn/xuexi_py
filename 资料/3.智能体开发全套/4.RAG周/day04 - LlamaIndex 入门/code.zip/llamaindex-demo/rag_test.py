import httpx
from llama_index.core import VectorStoreIndex
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.embeddings.openai_like import OpenAILikeEmbedding
from llama_index.llms.ollama import Ollama
from llama_index.core.settings import Settings
from dotenv import load_dotenv
import os

from llama_index.llms.openai_like import OpenAILike
from llama_index.readers.file import UnstructuredReader

# 加载环境变量
load_dotenv()

# 设置超时
httpx.Timeout(1200.0)

# 设置为全局默认Embedding模型
Settings.embed_model = OpenAILikeEmbedding(
    model_name="text-embedding-v3",
    api_key=os.getenv("API_KEY"),
    api_base=os.getenv("BASE_URL_CHAT")
)

# 设置为全局默认 LLM
Settings.llm = OpenAILike(
    model="qwen3.5-plus",
    api_key=os.getenv("API_KEY"),
    api_base=os.getenv("BASE_URL_CHAT"),
    is_chat_model=True
)

# 解析 pdf 文档
documents = UnstructuredReader().load_data(file="pdfs/python_faq.txt")
print(f"文档数量: {len(documents)}")


# 创建索引
index = VectorStoreIndex.from_documents(documents=documents,show_progress=True)
print(f"索引ID: {index.index_id}")

# 生成查询引擎
query_engine = index.as_query_engine()
print(f"查询引擎准备好: {query_engine}")

# 开启翻墙，要下载 解析器 模型
# 查询：这是个综合方法。 自动 查询 + 增强生成
response = query_engine.query("总结下文档内容")


print(response)