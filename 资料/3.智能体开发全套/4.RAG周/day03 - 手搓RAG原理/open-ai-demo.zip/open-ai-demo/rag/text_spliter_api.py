def split_text(text: str, chunk_size: int = 500, overlap: int = 100,
               separators: list[str] = None, metadata: dict = None) -> list[dict]:
    """
    文本切分函数

    Args:
        text: 要切分的文本
        chunk_size: 每个chunk的最大长度
        overlap: 相邻chunk的重叠长度
        separators: 分隔符列表，默认为常见标点和换行
        metadata: 基础元数据; 调用方法传入当时的元数据，

    Returns:
        切分后的chunk列表，每个chunk包含content和metadata
    """
    # 处理默认参数
    if separators is None:
        separators = ['\n\n', '\n', '。', '！', '？', ';', '；', ',', '，', ' ']

    # 处理空文本
    if not text:
        return []

    # 短文本直接返回
    if len(text) <= chunk_size:
        base_metadata = metadata.copy() if metadata else {}
        base_metadata.update({"chunk_index": 0, "chunk_total": 1})
        return [{"content": text, "metadata": base_metadata}]

    # 步骤1：按分隔符分割文本为小片段
    segments = [text]
    for sep in separators:
        new_segments = []
        for seg in segments:
            if sep in seg:
                parts = seg.split(sep)
                for i, part in enumerate(parts):
                    new_segments.append(part)
                    if i < len(parts) - 1:
                        new_segments.append(sep)
            else:
                new_segments.append(seg)
        segments = new_segments

    # 步骤2：合并小片段，避免产生过小的chunk
    merged_segments = []
    current_segment = ""
    for seg in segments:
        if len(current_segment) + len(seg) <= chunk_size:
            current_segment += seg
        else:
            if current_segment:
                merged_segments.append(current_segment)
            current_segment = seg
    if current_segment:
        merged_segments.append(current_segment)

    # 步骤3：切分合并后的段落，处理重叠
    chunks = []
    for seg in merged_segments:
        if len(seg) <= chunk_size:
            chunks.append(seg)
        else:
            # 无分隔符的长文本，兜底按字符截断
            start = 0
            while start < len(seg):
                end = min(start + chunk_size, len(seg))
                chunks.append(seg[start:end])
                start = end - overlap if end < len(seg) else end

    # 处理相邻chunk之间的重叠
    if len(chunks) > 1 and overlap > 0:
        overlapped_chunks = [chunks[0]]
        for i in range(1, len(chunks)):
            # 从上个chunk末尾取overlap长度的文本，添加到当前chunk开头
            prev_chunk = overlapped_chunks[-1]
            overlap_text = prev_chunk[-overlap:] if len(prev_chunk) >= overlap else prev_chunk
            current_chunk = overlap_text + chunks[i]
            # 确保当前chunk不超过chunk_size
            if len(current_chunk) > chunk_size:
                current_chunk = current_chunk[-chunk_size:]
            overlapped_chunks.append(current_chunk)
        chunks = overlapped_chunks

    # 步骤4：生成最终结果，添加元数据
    result = []
    base_metadata = metadata.copy() if metadata else {}
    total_chunks = len(chunks)

    for i, chunk in enumerate(chunks):
        chunk_metadata = base_metadata.copy()
        chunk_metadata.update({"chunk_index": i, "chunk_total": total_chunks})
        result.append({"content": chunk, "metadata": chunk_metadata})

    return result

## 测试切分

def test_split_text():
    from document_load_api import load_document
    # {content: "xx", metadata: {"source": "员工假期管理制度.pdf"}}
    doc = load_document("../测试物料/员工假期管理制度.pdf")
    chunks = split_text(doc["content"], chunk_size=500, overlap=50,metadata=doc["metadata"])
    for chunk in chunks:
        print(chunk["content"])


test_split_text()