from llama_index.core.agent import FunctionAgent
from llama_index.core.tools import FunctionTool
from llama_index.llms.openai_like import OpenAILike

from rag.agent_rag import get_agentic_rag_engine
from rag.config import Config
import asyncio

def multiply(a: float, b: float) -> float:
    """计算两个数字的乘积"""
    print(f"🔧调用：multiply({a}, {b})")
    return a * b


def build_agent():
    # 获取 RAG 引擎工具
    rag_tool = get_agentic_rag_engine()

    # 实例化 Agent，将工具列表传入
    calc_tool = FunctionTool.from_defaults(fn=multiply)

    agent = FunctionAgent(
        tools=[rag_tool, calc_tool],  # 可以传入多个工具
        llm=OpenAILike(
            model=Config.LLM_MODEL,
            api_key=Config.API_KEY,
            api_base=Config.BASE_URL,
            is_chat_model=True,
            is_function_calling_model=True,
            temperature=0.7
        ),
        system_prompt="你是一个有用的智能助手。你可以进行数学计算，并且能够搜索公司内部知识库来回答问题。",
    )
    return agent


# ⚠️ 将交互逻辑放入异步 main 函数中
async def main():
    agent = build_agent()

    while True:
        query_str = input("请输入您的问题: ").strip()
        if not query_str:
            continue
        if query_str == "exit":
            print("👋 再见！")
            break

        try:
            # ⚠️ 一定使用 await 来等待异步执行结果
            response = await agent.run(query_str)

            # 1. 测试日常闲聊（不需要调用工具）: 你好，我是张三。
            # 2. 测试工具调用（调用 calc_tool 计算 2 * 3）: 计算 2 * 3
            # 3. 测试 RAG 能力（Agent 会自动调用 rag_tool）: 辰光Agent平台用什么技术实现的？

            print(f"✅ 回答: {response}")
        except Exception as e:
            print(f"❌ 查询失败: {e}")

if __name__ == "__main__":
    # ⚠️ 使用 asyncio.run() 启动异步事件循环
    asyncio.run(main())