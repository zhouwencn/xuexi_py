import os

from rag.modular_rag import ModularRAG

if __name__ == "__main__":
    print("初始化 RAG 系统中，请稍候...")
    rag = ModularRAG()
    history = []

    print("\n🤔你好，我是你的项目小帮手，你可以向我提问，我会尽力回答。")
    while True:
        print("\n=== 菜单 ===")
        print("1：加载文档/目录")
        print("2：查询问题")
        print("3：退出")
        choice = input("请选择操作 (1/2/3): ").strip()

        if choice == "1":
            file_path = input("请输入要加载的文档或目录路径: ").strip()
            if os.path.exists(file_path):
                try:
                    rag.load(file_path)
                    print("✅ 文档加载并建立索引成功！")
                except Exception as e:
                    print(f"❌ 加载文档失败: {e}")
            else:
                print("❌ 路径不存在，请检查后重试。")

        elif choice == "2":
            if not rag.retriever:
                print("⚠️ 请先加载文档(选项1)！")
                continue

            query_str = input("请输入您的问题: ").strip()
            if not query_str:
                continue

            try:
                result = rag.query(query_str, history)
                print("\n" + "=" * 50)
                print(f"🤖 回答: {result['answer']}")
                print("=" * 50)
                print("📚 参考来源:")
                for source in result.get("sources", []):
                    # 获取前50个字符作为摘要
                    content_preview = str(source.get('content', '')).replace('\n', ' ')[:50]
                    score = source.get('score', 0)
                    print(f"  - [{source.get('id', '?')}] {content_preview}... (相关度: {score:.4f})")
                print("=" * 50)

                # 记录对话历史，保留最近的几轮即可
                history.append({"role": "user", "content": query_str})
                history.append({"role": "assistant", "content": result['answer']})
                if len(history) > 6:  # 保留最近3轮对话
                    history = history[-6:]
            except Exception as e:
                print(f"❌ 查询失败: {e}")

        elif choice == "3":
            print("👋 再见！")
            break

        else:
            print("⚠️ 无效的选择，请重新输入。")