from llama_index.core import VectorStoreIndex, Settings
from llama_index.core.retrievers import VectorIndexRetriever, QueryFusionRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from config import Config
from typing import List, Dict

class Retriever:
    def __init__(self, index: VectorStoreIndex):
        self.index = index
        self.vector_retriever = VectorIndexRetriever(
            index=index,
            similarity_top_k=Config.TOP_K
        )

    # 向量检索
    def vector_search(self, query: str):
        # 屏蔽细节： 问题也得向量化
        return self.vector_retriever.retrieve(query)

    # 混合检索: 并行检索 3 个查询，取 3 个最相关的结果
    def hybrid_search(self, query: str):
        # 创建混合检索器
        query_fusion_retriever = QueryFusionRetriever(
            [self.vector_retriever],
            similarity_top_k=Config.TOP_K,
            num_queries=3, # 会并行检索 3 个查询. 混合检索器内部行为。
            use_async=True, # 异步检索
            verbose=True
        )
        return query_fusion_retriever.retrieve(query)

    def retrieve(self, processed_query: Dict, use_hybrid: bool = True):
        if use_hybrid:
            return self.hybrid_search(processed_query["rewritten"])
        else:
            return self.vector_search(processed_query["rewritten"])

from rag.indexer import Indexer
def test():
    indexer = Indexer()
    # 加载已存在的索引
    index = indexer.load_existing_index()

    # 创建检索器
    retriever = Retriever(index = index)

    # 测试检索
    nodes = retriever.retrieve({"rewritten": "辰光Agent平台用了哪些技术"})

    print(f"检索 到 {len(nodes)} nodes \n {nodes}")

# test()