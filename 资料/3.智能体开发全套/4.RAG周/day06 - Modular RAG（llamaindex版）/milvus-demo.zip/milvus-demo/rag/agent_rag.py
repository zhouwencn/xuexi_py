from typing import Any, Optional
from pydantic import Field, ConfigDict

from llama_index.core.query_engine import CustomQueryEngine
from llama_index.core.base.response.schema import Response
from llama_index.core.tools import QueryEngineTool, ToolMetadata

# 导入项目中的模块
from rag.indexer import Indexer
from rag.post_processor import PostProcessor
from rag.generator import Generator
from rag.retriver import Retriever
from rag.query_processor import QueryProcessor


# 如果让RAG成为一个工具，最终被智能体调用。
# RAG 流程必须是一个 查询引擎(QueryEngine)
class MyAgenticRAG(CustomQueryEngine):
    """
    继承 CustomQueryEngine，必须遵循 Pydantic BaseModel 的规则。
    """
    # 1. 允许传入任意类型的 Python 对象（你的自定义类）
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # 2. 将组件声明为类属性（Pydantic 字段），使用 Field 延迟初始化
    indexer: Indexer = Field(default_factory=Indexer)
    query_processor: QueryProcessor = Field(default_factory=QueryProcessor)
    post_processor: PostProcessor = Field(default_factory=PostProcessor)
    generator: Generator = Field(default_factory=Generator)

    # 允许为 None，并在下方的模型验证后逻辑中初始化
    retriever: Optional[Retriever] = None
    index: Optional[Any] = None

    # 3. 替代 __init__：使用 Pydantic 的模型后初始化方法
    def model_post_init(self, __context: Any) -> None:
        """Pydantic 实例化后自动调用，用于加载索引和检索器"""
        try:
            self.index = self.indexer.load_existing_index()
            # 拿到查询器
            self.retriever = Retriever(self.index)
        except Exception as e:
            print(f"⚠️ 未能加载已有索引 (可能还未建立): {e}")
            self.index = None
            self.retriever = None

    # RAG 的流程
    # 4. 重写 custom_query 方法（核心逻辑不变）
    def custom_query(self, query_str: str) -> Response:
        if not self.retriever:
            return Response(response="⚠️ 请先加载文档构建索引！")

        print(f"\n🐻AgenticRAG[1/4] 开始处理查询: {query_str}")
        processed_query = self.query_processor.process(query_str, [])

        print(f"🐻AgenticRAG[2/4] 开始检索文档...")
        nodes = self.retriever.retrieve(processed_query)

        print(f"🐻AgenticRAG[3/4] 开始后处理(重排/过滤)...")
        processed_nodes = self.post_processor.process(nodes, processed_query["rewritten"])

        print(f"🐻AgenticRAG[4/4] 开始生成回答...")
        # 假设 generator.generate_with_sources 返回字典: {"answer": "...", "sources": [...]}
        gen_result = self.generator.generate_with_sources(processed_query["rewritten"], processed_nodes)

        # 5. 建议将结果包装为 LlamaIndex 原生的 Response 对象
        # 这样 Tool 和 Agent 就能完美解析你的返回文本和引用的节点
        return Response(
            response=str(gen_result.get("answer", "")),
            source_nodes=gen_result.get("sources", [])  # 将检索并过滤后的节点附加为来源
        )


# 获取 RAG 引擎
def get_agentic_rag_engine() -> QueryEngineTool:
    """
    获取辰光Agent的RAG引擎工具。
    :return: 一个QueryEngineTool对象，用于查询《辰光Agent》相关文档。
    """
    rag = MyAgenticRAG()

    # 把整个 RAG 引擎，包装为一个工具
    rag_tool = QueryEngineTool(
        query_engine=rag,
        metadata=ToolMetadata(
            name="chenguang_docs_search",
            description="用于查询《辰光Agent》相关的架构、功能、操作指南和内部文档。"
                        "当用户问题涉及辰光平台细节时调用此工具。"
        )
    )
    return rag_tool