from llama_index.core import  VectorStoreIndex, StorageContext, Settings, Document
from llama_index.core.node_parser import SentenceSplitter, SentenceWindowNodeParser, MarkdownNodeParser
from llama_index.core.schema import BaseNode
from llama_index.embeddings.openai_like import OpenAILikeEmbedding
from llama_index.llms.openai_like import OpenAILike
from llama_index.readers.file import UnstructuredReader
from llama_index.vector_stores.milvus import MilvusVectorStore
from rag.config import Config


class Indexer:
    def __init__(self):
        # 大语言模型：用于生成文本
        Settings.llm = OpenAILike(
            model=Config.LLM_MODEL,
            api_key=Config.API_KEY,
            api_base=Config.BASE_URL,
            is_chat_model=True,  # 如果不写，报错：不支持 model 模型
            is_function_calling_model=True,
            timeout=300
        )

        # 嵌入模型：用于将文本转换为向量表示
        Settings.embed_model = OpenAILikeEmbedding(
            model_name=Config.EMBEDDING_MODEL,
            api_key=Config.API_KEY,
            api_base=Config.BASE_URL,
            timeout=300
        )

        # 向量数据库：用于存储和检索向量表示
        ## MilvusVectorStore实例创建，默认效果
        ## 1. 创建对应的 collection_name
        ## 2. 集合指定了默认的 schema

        self.vector_store = MilvusVectorStore(
            uri=Config.MILVUS_URI,
            collection_name=Config.MILVUS_COLLECTION_NAME,
            dim=Config.MILVUS_DIM,
        )



        ## StorageContext： 存储上下文。 和存储有关的所有组件都在这里配置。
        self.storage_context = StorageContext.from_defaults(vector_store=self.vector_store)


    # 加载文档
    def load_documents(self, file: str) -> list[Document]:
        # Unstructured 读取文档
        reader = UnstructuredReader()
        # 写的复杂一点。
        return reader.load_data(file=file,split_documents=False)

    # 拆分文档
    def split_documents(self, documents: list[Document]) -> list[BaseNode]:

        # 语义拆分器： 语义被分割； 按照单词硬拆
        # parser = SentenceSplitter(
        #     chunk_size=Config.CHUNK_SIZE,
        #     chunk_overlap=Config.CHUNK_OVERLAP
        # )
        #
        # # 语义窗口拆分器： 文档，拆成一个个完整的句子；优点：保留完整语义；缺点：每个 chunk 太多了
        # window_parser = SentenceWindowNodeParser(
        #     sentence_splitter=parser,
        #     window_size=3,
        #     window_metadata_key="window",
        #     original_text_metadata_key="original_text",
        #     include_metadata=True,
        #     include_prev_next_rel=True,
        # )

        # markdown 拆分器； 测试各种拆分器的用法
        print(f"开始将 {len(documents)} 个文档拆分成 chunk 段落...")
        return MarkdownNodeParser().get_nodes_from_documents(documents=documents,show_progress=True)

    # 构建索引：把拆分后的段落，保存到向量库中
    def build_index(self, nodes):

        # 只要创建 VectorStoreIndex 对象，数据就会被写入向量库中。
        # 屏蔽了：文本 => 向量表示 的过程。
        # 必须 提前 在 Settings.embed_model 中配置好嵌入模型。
        index = VectorStoreIndex(
            nodes,
            storage_context=self.storage_context,
            show_progress=True
        )
        return index


    # 索引文档： 传入文件位置; 返回索引
    def index_documents(self, directory: str):
        print(f"😄从 {directory} 中加载文档...")
        documents = self.load_documents(directory)
        print(f"👌已加载 {len(documents)} 个文档")

        print("🔓开始将文档拆分成段落...")
        nodes = self.split_documents(documents)
        print(f"👌已拆分成 {len(nodes)} 个段落")

        print("📚开始构建索引...")
        index = self.build_index(nodes)
        print("👌索引构建完成!")


        return index

    # 加载已存在的索引
    def load_existing_index(self) -> VectorStoreIndex:
        return VectorStoreIndex.from_vector_store(
            self.vector_store,
            storage_context=self.storage_context
        )


def test_index():
    indexer = Indexer()

    index = indexer.index_documents("../docs/辰光Agent平台说明书.md")
    print(f"👌 索引构建完成。{index.index_id}")

# test_index()