from llama_index.core import SimpleDirectoryReader, VectorStoreIndex, Document
from llama_index.readers.file import UnstructuredReader
from unstructured.partition.auto import partition

## partition 返回 list[Element]
##  list[Document]
# 读取目录下的所有文件
# documents = SimpleDirectoryReader(input_dir="./测试物料").load_data(show_progress=True)
#
# print(f"文档数量: {len(documents)}")
# for document in documents:
#     print(document)

# documents = UnstructuredReader().load_data(file="./测试物料/辰光Agent平台说明书.md")
# print(f"文档数量: {len(documents)}")


# 用 llamaIndex 得到 documents 文档，可以直接一句话进向量库
# VectorStoreIndex().from_documents(documents)

# 调用 partition 解析文档。包装为 Document 对象
elements = partition("测试物料/辰光Agent平台说明书.md",strategy="fast")
documents = []
for ele in elements:
    documents.append(Document(doc_id=ele.id, text=ele.text))

VectorStoreIndex().from_documents(documents)


