# 示例 1：快速模式
from unstructured.partition.auto import partition

# ele = partition("测试物料/辰光Agent平台说明书.md",strategy="fast")
# for line in ele:
#     print(line)

# list[Element]: Element包含 category, text, metadata
# ele = partition("测试物料/辰光Agent平台说明书.md",strategy="fast")
# for line in ele:
#     print(line)


############################# 以下配好环境自行测试 ######################
# 示例 2：本地高精度解析 PDF（支持扫描件 + 表格）
from unstructured.partition.auto import partition

# 本地高精度解析（自动使用 local-inference 模型）
elements = partition(
    "pdfs/IBM商业价值研究院：2026年AI引领保险业变革时代报告.pdf",
    strategy="hi_res",  # 必须用高精度模式
    infer_table_structure=True,  # 开启表格识别
)
#
# # 输出解析后的内容
for elem in elements:
    print(f"类型：{elem.category}")
    print(f"内容：{elem.text}\n")
#
#
# # 示例 3：纯 ocr 模式
elements = partition(
    "图片.png",
    strategy="ocr_only"
)
#
text = "\n".join([e.text for e in elements])
print("识别结果：", text)

