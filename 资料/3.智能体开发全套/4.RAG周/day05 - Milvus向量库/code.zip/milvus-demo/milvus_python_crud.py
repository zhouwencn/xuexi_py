import random

from pymilvus import (
    connections,
    Collection,
    CollectionSchema,
    FieldSchema,
    DataType,
    utility
)

# -------------------------- 1. 连接 Milvus（核心第一步）--------------------------
def connect_milvus():
    """连接 Milvus 服务，新手无需修改参数"""
    try:
        # 断开现有连接（避免重复连接）
        if connections.has_connection("default"):
            connections.disconnect("default")

        # 连接 Milvus（host 为 localhost，port 为 19530，与 Docker 配置一致）
        connections.connect(
            alias="default",
            host="localhost",
            port=19530,
            timeout=30  # 超时时间，单位：秒
        )
        print("✅ 成功连接 Milvus 服务")
    except Exception as e:
        print(f"❌ 连接 Milvus 失败：{str(e)}")
        raise SystemExit(1)


# -------------------------- 2. 创建集合（Create）--------------------------
def create_collection(collection_name="test_collection", dim=1536):
    """
    创建 Milvus 集合（类比 MySQL 创建表）
    :param collection_name: 集合名（自定义）
    :param dim: 向量维度（根据自己的嵌入模型调整，本文用 1536 示例）
    """
    try:
        # 检查集合是否已存在，存在则删除（新手方便测试，生产环境谨慎）
        if utility.has_collection(collection_name):
            utility.drop_collection(collection_name)
            print(f"⚠️  集合 {collection_name} 已存在，已删除")

        # 1. 定义字段（必配 3 个核心字段）
        fields = [
            # 主键字段：自动生成，唯一标识每条数据
            FieldSchema(
                name="id",
                dtype=DataType.INT64,
                is_primary=True,
                auto_id=True
            ),
            # 向量字段：存储向量数据，维度为 dim
            FieldSchema(
                name="embedding",
                dtype=DataType.FLOAT_VECTOR,
                dim=dim
            ),
            # 元数据字段：存储附加信息（如文本内容），JSON 类型灵活存储
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON
            )
        ]

        # 2. 创建集合 schema（描述集合结构）
        schema = CollectionSchema(
            fields=fields,
            description="Milvus 测试集合（包含主键、向量、元数据）"
        )

        # 3. 创建集合
        collection = Collection(
            name=collection_name,
            schema=schema,
            using="default"
        )

        # 4. 创建索引（加速检索，新手首选 IVF_FLAT）
        index_params = {
            "index_type": "IVF_FLAT",
            "metric_type": "L2",  # 度量类型：L2（欧氏距离），常用场景
            "params": {"nlist": 128}  # 索引参数，无需修改，适配中小规模数据
        }


        collection.create_index(
            field_name="embedding",  # 对向量字段创建索引
            index_params=index_params,
            index_name="embedding_index"
        )

        # 加载集合（必须加载，否则无法检索）
        collection.load()


        print(f"✅ 成功创建并加载集合：{collection_name}")
        return collection
    except Exception as e:
        print(f"❌ 创建集合失败：{str(e)}")
        raise


# -------------------------- 3. 插入数据（Insert）--------------------------
def insert_data(collection, data_count=10):
    """
    插入数据到集合（类比 MySQL insert）
    :param collection: 集合对象（create_collection 返回的结果）
    :param data_count: 插入数据条数（自定义，新手用 10 条测试）
    """
    try:
        # 模拟数据：生成 10 条向量 + 元数据（实际场景中，向量由嵌入模型生成）
        insert_data = [
            # 向量字段：生成 1536 维随机向量（模拟嵌入模型输出）
            [random.random() for _ in range(1536)] for _ in range(data_count)
        ]
        metadata_list = [
            # 元数据字段：存储每条向量的附加信息
            {"text": f"测试文本{i}", "source": "milvus_test"} for i in range(data_count)
        ]

        # 插入数据（注意：数据顺序要与字段顺序一致：embedding、metadata，主键自动生成）
        result = collection.insert(
            data=[insert_data, metadata_list]
        )

        # 刷新数据（确保数据写入磁盘，避免查询不到）
        collection.flush()
        print(f"✅ 成功插入 {data_count} 条数据，插入 ID：{result.primary_keys}")
        return result.primary_keys  # 返回插入的主键 ID，后续更新/删除会用到
    except Exception as e:
        print(f"❌ 插入数据失败：{str(e)}")
        raise


# -------------------------- 4. 查询数据（Read）--------------------------
def search_data(collection, query_vector=None, top_k=3):
    """
    相似度查询（Milvus 核心功能，类比 MySQL select）
    :param collection: 集合对象
    :param query_vector: 查询向量（默认生成随机向量，模拟实际查询场景）
    :param top_k: 返回最相似的 k 条数据
    """
    try:
        # 模拟查询向量（实际场景中，由用户查询文本通过嵌入模型生成）
        if query_vector is None:
            query_vector = [random.random() for _ in range(1536)]

        # 定义查询参数
        search_params = {
            "metric_type": "L2",
            "params": {"nprobe": 10}  # 检索参数，无需修改； nprobe 为检索时的探针数量，默认 10
        }

        # 执行相似度查询（指定要返回的字段：metadata）
        results = collection.search(
            data=[query_vector],  # 查询向量（可批量查询，传入列表）
            anns_field="embedding",  # 按向量字段检索
            param=search_params,
            limit=top_k,  # 返回 top_k 条最相似数据
            output_fields=["metadata"]  # 返回元数据字段（按需指定）
        )

        # 解析查询结果
        print(f"\n🔍 相似度查询结果（top {top_k}）：")
        for i, result in enumerate(results[0]):
            # 打印：相似度距离（越小越相似）、主键 ID、元数据
            print(f"第{i + 1}条：距离={result.distance:.4f}，ID={result.id}，元数据={result.entity.get('metadata')}")

        return results
    except Exception as e:
        print(f"❌ 查询数据失败：{str(e)}")
        raise
# -------------------------- 5. 更新数据（Update）--------------------------
def update_data(collection, primary_id, new_metadata):

    """
        upsert接口是 Milvus 实现数据更新的核心方式，通过 ID 匹配实现 “存在即更新，不存在即插入”；
        更新操作需先定义包含目标 ID 和新字段值的数据列表，再调用upsert接口执行；
        注意：
        1. 更新时需指定 partial_update=True，否则会插入新数据而不是更新；
    """
    try:
        # 1. 先查询原数据，获取对应向量（upsert 需传入完整向量+新元数据，向量不变仅更新元数据）
        expr = f"id == {primary_id}"
        res = collection.query(expr=expr, output_fields=["embedding", "metadata"])
        if not res:
            raise ValueError(f"未找到 ID={primary_id} 的数据，无法更新")
        # 提取原向量（保持向量不变，仅更新元数据）
        data = {
            "id": primary_id,
            "metadata": new_metadata
        }

        res = collection.upsert(data=data,partial_update = True)
        collection.flush()
        print(f"✅ 成功更新 ID={primary_id} 的数据，更新条数：{res.upsert_count}，插入条数：{res.insert_count}")
    except Exception as e:
        print(f"❌ 更新数据失败：{str(e)}")
        # 补充报错排查提示，帮助新手定位问题
        if "upsert" in str(e):
            print("⚠️  排查提示：请确认集合创建时已开启 enable_dynamic_field，且主键 ID 存在")
        raise

# -------------------------- 6. 删除数据（Delete）--------------------------
def delete_data(collection, primary_ids):
    """
    删除数据（按主键删除，类比 MySQL delete）
    :param collection: 集合对象
    :param primary_ids: 要删除的主键 ID 列表（可批量删除）
    """
    try:
        # 按主键筛选删除（支持批量删除，expr 用 in 语法）
        expr = f"id in {primary_ids}"
        result = collection.delete(expr=expr)
        collection.flush()
        print(f"✅ 成功删除 {result.delete_count} 条数据，删除 ID：{primary_ids}")
    except Exception as e:
        print(f"❌ 删除数据失败：{str(e)}")
        raise
if __name__ == "__main__":
    # 建立连接
    connect_milvus()
    collection = create_collection()

    results = insert_data(collection)

    # update_data(collection, primary_id=results[0], new_metadata={"text": "更新后的文本22222", "source": "milvus_test222"})
    delete_data(collection, primary_ids=[results[0]])


