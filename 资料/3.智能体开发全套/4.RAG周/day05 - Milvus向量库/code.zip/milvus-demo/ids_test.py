from pymilvus import MilvusClient, DataType

client = MilvusClient()
res = client.search(
    collection_name="quick_setup",
    anns_field="vector",
    ids=[1, 2, 4], # a list of primary keys
    filter='color like "red%" and likes > 50',
    output_fields=["color", "likes"],
    limit=3,
    search_params={"metric_type": "COSINE","params": {
            "radius": 0.4,
            "range_filter": 1.0
        }},
)

for hits in res:
    for hit in hits:
        print(hit)