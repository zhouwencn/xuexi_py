from langchain.agents import create_agent
from langchain.agents.structured_output import ToolStrategy
from langchain_deepseek.chat_models import ChatDeepSeek
from dotenv import load_dotenv
import os

load_dotenv()

# 1. 系统提示词
SYSTEM_PROMPT = """
你是一名专业的天气预报员。

你可以使用两个工具：
1. get_weather_for_location：用于获取指定地点的天气信息
2. get_user_location：用于获取用户当前所在位置

如果用户向你询问天气，请务必先明确地点。如果从问题中能判断出用户想知道他所在位置的天气，请调用 get_user_location 工具获取其位置。
"""

# 2. 创建工具
from dataclasses import dataclass
from langchain.tools import tool, ToolRuntime

@tool
def get_weather_for_location(city: str) -> str:
    """获取指定地点的天气信息."""

    # 方法名、参数名、方法描述 都要语义化
    return f"{city} 今天是晴天!☀️"

@dataclass # 这是专门封装数据
class MyContext:
    """自定义运行时上下文."""
    user_id: str

@tool
def get_user_location(runtime: ToolRuntime[MyContext]) -> str:
    """根据 user_id 获取用户当前所在位置."""
    user_id = runtime.context.user_id
    return "北京" if user_id == "1" else "上海"


# 3. 定义模型
chat_model = ChatDeepSeek(
    model=os.getenv("DEEPSEEK_MODEL"),
    api_key=os.getenv("DS_API_KEY"),
    temperature=0.7
)




from langgraph.checkpoint.memory import InMemorySaver

# 5. 内存记忆
checkpointer = InMemorySaver()

# 6. 格式化输出；  自定义的 json schema。
@dataclass
class MyResponseFormat:
    """agent 响应格式化."""
    # 响应文本 (必须)
    response_text: str
    # 天气条件 (可选)
    weather_conditions: str | None = None
    # 用户位置 (可选)
    user_location: str | None = None


# 7. 创建 Agent
## 直接写模型名字，需要根据不同模型的要求，在环境变量配置信息
agent = create_agent(
    model="deepseek-chat",
    tools=[get_weather_for_location, get_user_location],
    system_prompt=SYSTEM_PROMPT,
    response_format=ToolStrategy(MyResponseFormat),
    checkpointer=checkpointer, # 内存记忆
    context_schema=MyContext,
)

# 8. 测试对话
# `thread_id` 每个会话唯一标识:  固定要求：'configurable'
#       keys: thread_id, checkpoint_ns（namespace）, checkpoint_id
# 这样来区分每个用户的会话。 thread_id 不一样就代表不同的会话。
# 这也是【内存记忆隔离机制】；

config = {"configurable": {"thread_id": "1"}}

# 支持期间，动态传入上下文数据。 agent之间就隔离
response =agent.invoke(
    input={"messages": [{"role": "user", "content": "我是雷丰阳，北京天气如何？"}]},
    config=config,
    context=MyContext(user_id="1")
)

# 通过 debug 查看 response 的 messages 记录，发现 格式化输出本质就是一个工具调用
print(f"第一次：模型回复：{response['structured_response']}")


# 第二次测试，模型会话上下文（短期记忆）
response =agent.invoke(
    input={"messages": [{"role": "user", "content": "谢谢! 你知道我名字吗？"}]},
    config=config,
    context=MyContext(user_id="1")
)
print(f"第二次：模型回复：{response['structured_response']}")
