from langchain.agents import AgentState, create_agent
from langchain.agents.middleware import AgentMiddleware
from typing import Any
from dotenv import load_dotenv
load_dotenv()

# 继承 AgentState; 可以在 Invoke 运行时传递数据
class CustomState(AgentState):
    user_preferences: dict

# 中间件  AgentMiddleware： 提供了各种拦截时机
class CustomMiddleware(AgentMiddleware):
    state_schema = CustomState

    # 希望在模型调用前，访问短期记忆数据
    def before_model(self, state: CustomState, runtime) -> dict[str, Any] | None:
        # 随时访问 短期记忆 数据
        print(f"在中间件中访问到了短期记忆【state】数据：{state.get('user_preferences')}")
        return None


agent = create_agent(
    "deepseek-chat",
    # tools=tools,
    middleware=[CustomMiddleware()]
)

# agent 可以追踪额外的状态信息了（user_preferences），
result = agent.invoke({
    "messages": [{"role": "user", "content": "I prefer technical explanations"}],
    "user_preferences": {"style": "technical", "verbosity": "detailed"},
})

result = agent.invoke({
    "messages": [{"role": "user", "content": "I prefer technical explanations"}],
    "user_preferences": {"style": "aaaa", "verbosity": "bbbb"},
})