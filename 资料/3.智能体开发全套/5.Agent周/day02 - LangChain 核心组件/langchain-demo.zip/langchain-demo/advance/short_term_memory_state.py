from langchain.agents import AgentState, create_agent


# 定义自定义状态
class CustomState(AgentState):
    user_preferences: dict

agent = create_agent(
    "deepseek-chat",
    # tools=[a,b], # 以后所有的工具调用期间，都能访问到 state_schema 中的数据
    state_schema=CustomState
)
# agent 可以追踪额外的状态信息了（user_preferences），
result = agent.invoke({
    "messages": [{"role": "user", "content": "I prefer technical explanations"}],
    "user_preferences": {"user_id": "123456", "verbosity": "detailed"}, # 跨节点共享一些数据
})

