from pydantic import BaseModel
from langchain.agents import create_agent
from langchain.agents.structured_output import ToolStrategy
from dotenv import load_dotenv

load_dotenv()


# 结构化输出
class ContactInfo(BaseModel):
    name: str
    email: str
    phone: str

# 结构化输出，本身就是一个工具调用。
agent = create_agent(
    model="deepseek-chat",
    # response_format=ToolStrategy(ContactInfo) # 开启结构化输出
    response_format=ContactInfo  # 默认使用 provider 结构化输出，如果不行，就使用 ToolStrategy 结构化输出
)

result = agent.invoke({
    "messages": [{"role": "user", "content": "Extract contact info from: John Doe, john@example.com, (555) 123-4567"}]
})

# 从结果的 "structured_response" 字段提取内容
print(f"结构化输出：{result['structured_response']}")
