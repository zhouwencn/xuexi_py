from langchain.agents import create_agent
from langchain.messages import AIMessage, HumanMessage
from dotenv import load_dotenv
from langchain_core.tools import tool

load_dotenv()




@tool
def add(a, b):
    """Add two numbers together."""
    print(f"Adding {a} and {b}")
    return a + b

agent  = create_agent(
    "deepseek-chat",
    tools=[add]
)


# 解析流式数据
def updates_for(response):
    for update in response:
        if update.get('model'):
            print(f"模型回复: {update['model']['messages'][-1]}")

        elif update.get('tools'):
            print(f"工具调用: {update['tools']['messages'][-1]}")

# 如果解析流式数据;
def values_for(response):
    for chunk in response:
        print(chunk)
        msg = chunk['messages'][-1]  # 获取最新消息
        if msg.content:
            if isinstance(msg, HumanMessage):
                print(f"User: {msg.content}")
            if isinstance(msg, AIMessage):
                print(f"Agent: {msg.content}")


def messages_for(response):
    for chunk in response:
        print(chunk[0].content,end='')

# 流式响应，返回一个个的 chunk（返回一个生成器，需要迭代）
response = agent.stream({
    "messages": [{"role": "user", "content": "计算 1 + 2 等于多少"}]
},stream_mode="messages")

messages_for(response)
## 1. values： 每次1步，一步完成，返回一个 chunk，封装这一步的完整数据； 所有消息攒到历史消息中
## 2. updates： 每次1步，一步完成，返回一个 chunk，封装这一步的完整数据； 只给新一步的内容
## 3. messages： 每次 一批token。打字机效果。
