from langchain.agents import create_agent
from langchain.agents.middleware import wrap_model_call, ModelRequest, ModelResponse, wrap_tool_call
from langchain.agents.structured_output import ToolStrategy
from langchain_core.messages import ToolMessage
from langchain_deepseek.chat_models import ChatDeepSeek
from langchain_community.chat_models import ChatTongyi
from dotenv import load_dotenv
import os

load_dotenv()

# 1. 系统提示词
SYSTEM_PROMPT = """
你是一名专业的天气预报员。

你可以使用两个工具：
1. get_weather_for_location：用于获取指定地点的天气信息
2. get_user_location：用于获取用户当前所在位置

如果用户向你询问天气，请务必先明确地点。如果从问题中能判断出用户想知道他所在位置的天气，请调用 get_user_location 工具获取其位置。
"""

# 2. 创建工具
from dataclasses import dataclass
from langchain.tools import tool, ToolRuntime

@tool
def get_weather_for_location(city: str) -> str:
    """获取指定地点的天气信息."""

    # 方法名、参数名、方法描述 都要语义化
    return f"{city} 今天是晴天!☀️"

@tool
def divide(a: int, b: int) -> str:
    """两数除法. 返回最终结果字符串 """

    # 方法名、参数名、方法描述 都要语义化
    return f"{a/b}"

@dataclass # 这是专门封装数据
class MyContext:
    """自定义运行时上下文."""
    user_id: str

@tool
def get_user_location(runtime: ToolRuntime[MyContext]) -> str:
    """根据 user_id 获取用户当前所在位置."""
    user_id = runtime.context.user_id
    return "北京" if user_id == "1" else "上海"


# 3. 定义模型
chat_model = ChatDeepSeek(
    model=os.getenv("DEEPSEEK_MODEL"),
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    temperature=0.7
)

chat_model_qw =ChatTongyi(
    model=os.getenv("CHAT_MODEL"),
    api_key=os.getenv("API_KEY"),
    max_retries=3,
    top_p=0.7
)

# 动态决定用什么模型； 模型调用前后会进行拦截
@wrap_model_call
def dynamic_model_selection(request: ModelRequest, handler) -> ModelResponse:
    # 判断消息上下文信息
    length = len(request.messages[-1].content)
    if length > 10:
        model = chat_model
    else:
        # model = chat_model_qw  # 返回qwen模型会爆炸，是因为 qwen 不支持 tool_choice=auto/none/any
        model = chat_model

    return handler(request.override(model=model))

# 一定注册到 Agent 中
@wrap_tool_call
def handle_tool_errors(request, handler):
    """Handle tool execution errors with custom messages."""
    try:
        return handler(request)
    except Exception as e:
        # Return a custom error message to the model
        return ToolMessage(
            content=f"❌️工具调用错误: ({str(e)})",
            tool_call_id=request.tool_call["id"]
        )


from langgraph.checkpoint.memory import InMemorySaver

# 5. 内存记忆
checkpointer = InMemorySaver()

# 6. 格式化输出；  自定义的 json schema。
@dataclass
class MyResponseFormat:
    """agent 响应格式化."""
    # 响应文本 (必须)
    response_text: str
    # 天气条件 (可选)
    weather_conditions: str | None = None
    # 用户位置 (可选)
    user_location: str | None = None


# 7. 创建 Agent
## 直接写模型名字，需要根据不同模型的要求，在环境变量配置信息
agent = create_agent(
    model="deepseek-chat",
    tools=[get_weather_for_location, get_user_location,divide],
    system_prompt=SYSTEM_PROMPT,
    response_format=ToolStrategy(MyResponseFormat),
    checkpointer=checkpointer, # 内存记忆
    context_schema=MyContext,
    middleware=[dynamic_model_selection,handle_tool_errors] # 动态选择模型
)

# 8. 测试对话
# `thread_id` 每个会话唯一标识:  固定要求：'configurable'
#       keys: thread_id, checkpoint_ns（namespace）, checkpoint_id
# 这样来区分每个用户的会话。 thread_id 不一样就代表不同的会话。
# 这也是【内存记忆隔离机制】；

config = {"configurable": {"thread_id": "1"}}

# # 支持期间，动态传入上下文数据。 agent之间就隔离
# response =agent.invoke(
#     input={"messages": [{"role": "user", "content": "我是雷丰阳，北京天气如何？"}]},
#     config=config,
#     context=MyContext(user_id="1")
# )
#
# # 通过 debug 查看 response 的 messages 记录，发现 格式化输出本质就是一个工具调用
# print(f"第一次：模型回复：{response['structured_response']} \n ")
#
#
# # 第二次测试，模型会话上下文（短期记忆）
# response =agent.invoke(
#     input={"messages": [{"role": "user", "content": "知道我名字吗？"}]},
#     config=config,
#     context=MyContext(user_id="1")
# )
# print(f"第二次：模型回复：{response['structured_response']}")


response =agent.invoke(
    input={"messages": [{"role": "user", "content": "8 除以 0 等于多少？"}]},
    config=config,
    context=MyContext(user_id="1")
)
print(f"模型回复：{response['structured_response']}")