# 统计使用多少 token； 三种
## 1. callback
# from langchain.chat_models import init_chat_model
# from dotenv import load_dotenv
# from langchain_core.callbacks import UsageMetadataCallbackHandler
#
# load_dotenv()
# model_1 = init_chat_model(model="deepseek-chat")
# model_2 = init_chat_model(model="deepseek-reasoner")
#
# # 收集处理 token Usage 信息
# callback = UsageMetadataCallbackHandler()
#
# result_1 = model_1.invoke("Hello", config={"callbacks": [callback]})
#
# result_2 = model_2.invoke("Hello", config={"callbacks": [callback]})
#
#
# print(callback.usage_metadata)


## 2. 上下文
from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
from langchain_core.callbacks import get_usage_metadata_callback

load_dotenv()
model_1 = init_chat_model(model="deepseek-chat")
model_2 = init_chat_model(model="deepseek-reasoner")


# response = model_1.invoke(
#     "讲个笑话",
#     config={
#         "run_name": "joke_generation",      # Custom name for this run
#         "tags": ["humor", "demo"],          # Tags for categorization
#         "metadata": {"user_id": "123"},     # Custom metadata
#         "callbacks": [callback], # Callback handlers
#     }
# )

# with get_usage_metadata_callback() as cb:
#     model_1.invoke("Hello")
#     model_2.invoke("Hello")
#     print(cb.usage_metadata)


## 3. response 中获取 usage 的数据
