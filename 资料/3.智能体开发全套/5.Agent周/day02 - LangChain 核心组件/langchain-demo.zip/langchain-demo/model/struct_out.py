from pydantic import BaseModel, Field

import asyncio

from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
load_dotenv()

# 初始化模型
model = init_chat_model("deepseek-chat")

from pydantic import BaseModel, Field

class Actor(BaseModel):
    name: str
    role: str


class MovieDetails(BaseModel):
    title: str
    year: int
    cast: list[Actor]


model_with_structure = model.with_structured_output(MovieDetails)

response = model_with_structure.invoke("介绍下电影《龙争虎斗》的细节")
print(response)