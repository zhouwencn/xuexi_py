from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
load_dotenv()

# 初始化模型
model = init_chat_model("deepseek-chat")

# 非流式响应
# response = model.invoke("你好，你是谁")
#
# print(f"模型回复: {response.content}")

# 方式二：维护消息历史（纯 dict 方式）
conversation = [
    {"role": "system", "content": "You are a helpful assistant that translates English to French."},
    {"role": "user", "content": "Translate: I love programming."},
    {"role": "assistant", "content": "J'adore la programmation."},
    {"role": "user", "content": "Translate: I love building applications."}
]

response = model.invoke(conversation)
print(response)  # AIMessage("J'adore créer des applications.")

# 方式三：维护消息历史（消息对象方式【推荐使用】）
from langchain.messages import HumanMessage, AIMessage, SystemMessage

conversation = [
    SystemMessage("You are a helpful assistant that translates English to French."),
    HumanMessage("Translate: I love programming."),
    AIMessage("J'adore la programmation."),
    HumanMessage("Translate: I love building applications.")
]

# 和模型聊天，把整个消息历史发出去。
response = model.invoke(conversation)
print(response)  # AIMessage("J'adore créer des applications.")
conversation.append(AIMessage(response.content))