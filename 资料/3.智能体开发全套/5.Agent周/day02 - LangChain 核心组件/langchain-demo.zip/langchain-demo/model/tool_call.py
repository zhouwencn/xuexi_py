from langchain_core.tools import tool
import asyncio

from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
load_dotenv()

# 初始化模型
model = init_chat_model("deepseek-reasoner")

@tool
def get_weather(location: str) -> str:
    """Get the weather at a location."""
    return f"It's sunny in {location}."


# 模型绑定工具
model_with_tools = model.bind_tools([get_weather])

response = model_with_tools.invoke("What's the weather in Boston and Tokyo?")
for tool_call in response.tool_calls:
    # View tool calls made by the model
    print(f"Tool: {tool_call['name']}")
    print(f"Args: {tool_call['args']}")
    # 自己解析工具调用