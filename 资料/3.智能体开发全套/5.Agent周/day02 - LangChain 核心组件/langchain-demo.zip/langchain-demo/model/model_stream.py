import asyncio

from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
load_dotenv()

# 初始化模型
model = init_chat_model("deepseek-reasoner")

async def main():
    # 流式事件
    async for event in model.astream_events("你好"):

        if event["event"] == "on_chat_model_start":
            print(f"Input: {event['data']['input']}")

        elif event["event"] == "on_chat_model_stream":
            print(f"Token: {event['data']['chunk'].text}")

        elif event["event"] == "on_chat_model_end":
            print(f"Full message: {event['data']['output'].text}")

        else:
            pass


def batch_test():
    msg_list = [
        "一句话介绍 LangChain?",
        "一句话介绍 机器学习?",
        "一句话介绍 深度学习?"
    ]
    config = {
        "max_concurrency": 3,
        "recursion_limit": 25 # 递归深度。最大思考次数
    }

    responses = model.batch(msg_list, config=config)
    for response in responses:
        print(response)
batch_test()


def aaa():
    # 方式二：解析 reasoning、tool_call、以及其他内容等； 核心需要判断  block["type"]
    for chunk in model.stream("一句话介绍 LangChain"):
        for block in chunk.content_blocks:
            if block["type"] == "reasoning" and (reasoning := block.get("reasoning")):
                print(f"推理: {reasoning}")
            elif block["type"] == "tool_call_chunk":
                print(f"工具袅: {block}")
            elif block["type"] == "text":
                print(f"{block["text"]}", end="")
            else:
                pass