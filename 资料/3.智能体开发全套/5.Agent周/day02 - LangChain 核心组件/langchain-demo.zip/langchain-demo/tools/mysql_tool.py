from langchain.agents import create_agent
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_deepseek.chat_models import ChatDeepSeek
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from dotenv import load_dotenv
from sqlalchemy import create_engine

load_dotenv()

engine = create_engine(
    "mysql+pymysql://root:123456@localhost:3306/my_db",
    echo=True,
    pool_size=10,
    max_overflow=20,
    pool_recycle=3600,
    pool_pre_ping=True,
)
# 1. 封装数据库
db = SQLDatabase(engine)


llm = ChatDeepSeek(model="deepseek-chat")

# 2. 封装数据库工具包
toolkit = SQLDatabaseToolkit(db=db, llm=llm)

for tool in toolkit.get_tools():
    print(f"tool: {tool}")


# 3. 获取提示词模板
from langchain_classic import hub

prompt_template = hub.pull("langchain-ai/sql-agent-system-prompt")
#
print(prompt_template.input_variables)
print(prompt_template.messages)
#
system_message = prompt_template.format(dialect="MySQL", top_k=5)
#
# # 4. 创建智能体
agent = create_agent(llm, toolkit.get_tools(), system_prompt=system_message)
#
# # 5. 测试
# example_query = "获取当前数据库信息，并查看数据库有哪些表？"
example_query = "给我创建一个示例的订单表，并插入3条测试数据"
#
events = agent.stream(
    {"messages": [("user", example_query)]},
    stream_mode="values",
)
for event in events:
    event["messages"][-1].pretty_print()