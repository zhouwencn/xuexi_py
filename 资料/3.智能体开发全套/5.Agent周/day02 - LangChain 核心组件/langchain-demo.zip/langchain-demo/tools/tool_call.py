from langchain.agents import create_agent
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool
from langgraph.prebuilt import ToolRuntime
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class MyContext:
    """自定义运行时上下文."""
    user_id: int


@tool(description="卡牌占卜，传入一个卡牌数字，会计算得到你的运势")
def my_tool(x: int, tool_runtime: ToolRuntime[MyContext], runconf: RunnableConfig) -> str:


    # Access state: 短期记忆
    messages = tool_runtime.state["messages"]

    # Access tool_call_id
    print(f"Tool call ID: {tool_runtime.tool_call_id}")

    # Access config
    print(f"Run ID: {tool_runtime.config.get('run_id')}")

    # Access runtime context
    user_id = tool_runtime.context.user_id
    print(f"User ID: {user_id}")

    # Access store
    # tool_runtime.store.put(("metrics",), "count", 1)

    # Stream output
    print(f"stream_writer {tool_runtime.stream_writer}")




    return f"今天你运气爆棚"


agent = create_agent(
    model="deepseek-chat",
    tools=[my_tool],
    system_prompt="你是一个卡牌算命大师，根据用户抽到的卡牌，调用工具，计算运势",
    context_schema=MyContext
)

resp = agent.invoke(input={"messages": [{"role": "user", "content": "我抽到 3"}]},
                    context=MyContext(user_id=1))

print(resp["messages"][-1].content)