from langchain.agents import create_agent
from langchain_community.chat_models.tongyi import  ChatTongyi
from langchain_openai.chat_models import ChatOpenAI
from langchain_deepseek.chat_models import ChatDeepSeek
from dotenv import load_dotenv
import os

load_dotenv()

# 定义工具
def get_weather(city: str) -> str:
    """Get weather for a given city."""
    print(f"🔧调用：查询 {city} 天气")
    return f"😄 {city} 今天是晴天!"

# 定义大模型
## 1. 用什么大模型创建什么示例
# chat_model =ChatTongyi(
#     model=os.getenv("CHAT_MODEL"),
#     api_key=os.getenv("API_KEY"),
#     max_retries=3,
#     top_p=0.7
# )


## 使用 OpenAI 兼容接口
# chat_model = ChatOpenAI(
#     model=os.getenv("CHAT_MODEL"),
#     api_key=os.getenv("API_KEY"),
#     base_url=os.getenv("BASE_URL_CHAT")
# )


## temperature 和 top_p（选中前 top_p% 的概率的词） 什么区别？
# temperature 控制模型的随机性，值越小，模型越确定，值越大，模型越随机。
# top_p 控制模型的输出，值越小，模型越确定，值越大，模型越随机。

chat_model = ChatDeepSeek(
    model=os.getenv("DEEPSEEK_MODEL"),
    api_key=os.getenv("DS_API_KEY"),
    temperature=0.7
)

# 创建 Agent： 从 create_agent 开始
## 1. 自动的工具调用  2. 自动维护消息历史
agent = create_agent(
    model=chat_model,
    tools=[get_weather],
    system_prompt="你是一个天气助手，可以调用工具帮用户查询天气"
)


response =agent.invoke( input={"messages": [{"role": "user", "content": "北京天气如何？"}]})

print(f"模型回复：{response}")
