import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from dotenv import load_dotenv
from langchain_mcp_adapters.interceptors import MCPToolCallRequest


load_dotenv()

# 四种： stream http、 sse、 stdio、 websocket
async def main():
    client = MultiServerMCPClient(
        {
            "tavily": {
                "transport": "http",
                "url": "https://mcp.tavily.com/mcp/?tavilyApiKey=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",
            }
        }
    )

    tools = await client.get_tools()
    print(f"Tools: {tools}")
    agent = create_agent(
        "deepseek-chat",
        tools
    )

    response =  agent.astream(
        {"messages": [{"role": "user", "content": "英伟达最新股价"}]},
        stream_mode="messages"
    )

    async for chunk in response:
        print(chunk[0].content,end='')

if __name__ == "__main__":
    asyncio.run(main())