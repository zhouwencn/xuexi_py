import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from dotenv import load_dotenv
load_dotenv()

async def main():
    client = MultiServerMCPClient(
        {

            "zhipu": {
                "transport": "sse",  # HTTP-based remote server
                # Ensure you start your weather server on port 8000
                "url": "https://open.bigmodel.cn/api/mcp/web_search/sse?Authorization=f1102c29960e4211b0ad6067c180a238.zVeZeIG6jwsISN4T"
            },
            "歌者PPT": {
                "transport": "stdio",
                "command": "npx",
                "args": [
                    "-y",
                    "gezhe-mcp-server@latest"
                ],
                "env": {
                    "API_KEY": "aaaaa"
                }
            }
        }
    )

    tools = await client.get_tools()
    for tool in tools:
        print(f"Tool: {tool}")
    agent = create_agent(
        "deepseek-chat",
        tools
    )
    math_response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "搜索雷丰阳老师信息"}]}
    )
    # weather_response = await agent.ainvoke(
    #     {"messages": [{"role": "user", "content": "查询 西安 的天气"}]}
    # )
    print(math_response)
    # print("="*50)
    # print(weather_response)

if __name__ == "__main__":
    asyncio.run(main())