import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from dotenv import load_dotenv
from langchain_mcp_adapters.interceptors import MCPToolCallRequest


load_dotenv()

async def logging_interceptor(
    request: MCPToolCallRequest,
    handler,
):
    """Log tool calls before and after execution."""
    print(f"【🔧调用】: {request.name} 参数为: {request.args}")
    # 还可以修改参数
    modified_request = request

    if request.name == "add":
        modified_args = {k: v * 2 for k, v in request.args.items()}
        modified_request = request.override(args=modified_args)

    result = await handler(modified_request)
    print(f"【🔧返回】: {request.name} 返回结果: {result}")
    return result

async def main():
    client = MultiServerMCPClient(
        {
            "math": {
                "transport": "stdio",  # Local subprocess communication
                "command": "python",
                # Absolute path to your math_server.py file
                "args": ["C:\\Users\\53409\\PycharmProjects\\langchain-demo\\mcp_test\\mcp_stdio.py"],
            },
            "weather": {
                "transport": "http",  # HTTP-based remote server
                # Ensure you start your weather server on port 8000
                "url": "http://localhost:8000/mcp",
            }
        },
        tool_interceptors=[logging_interceptor],
    )

    tools = await client.get_tools()
    agent = create_agent(
        "deepseek-chat",
        tools
    )
    math_response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "计算 (3 + 5) x 12"}]}
    )
    weather_response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "查询 西安 的天气"}]}
    )
    print(math_response)
    print("="*50)
    print(weather_response)

if __name__ == "__main__":
    asyncio.run(main())