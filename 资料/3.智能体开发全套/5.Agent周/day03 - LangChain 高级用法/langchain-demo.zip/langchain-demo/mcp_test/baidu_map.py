import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from dotenv import load_dotenv
load_dotenv()

async def main():
    client = MultiServerMCPClient(
        {
            "baidu_map": {
                "transport": "stdio",  # Local subprocess communication: 进程间通信技术
                "command": "python",
                # Absolute path to your math_server.py file
                "args": ["-m","mcp_server_baidu_maps"],
                "env": {
                    "BAIDU_MAPS_API_KEY": "0fyQ7m1lRyi7GpM6f6uYCwmCAyxG2d4G"
                }
            }
        }
    )

    tools = await client.get_tools()
    for tool in tools:
        print(f"Tool: {tool}")
    agent = create_agent(
        "deepseek-chat",
        tools
    )
    response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "故宫的经纬度是多少"}]}
    )

    print(response["messages"][-1])
    # weather_response = await agent.ainvoke(
    #     {"messages": [{"role": "user", "content": "查询 西安 的天气"}]}
    # )
    # print(math_response)
    # print("="*50)
    # print(weather_response)

if __name__ == "__main__":
    asyncio.run(main())