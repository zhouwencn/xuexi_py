from fastmcp import FastMCP

mcp = FastMCP("Weather")

@mcp.tool()
async def get_weather(location: str) -> str:
    """获取指定位置的天气信息"""
    return f"{location} 今天是晴天☀️"

@mcp.tool()
async def add(a: int, b: int) -> int:
    """两数相加"""
    return a + b


if __name__ == "__main__":
    mcp.run(transport="streamable-http")