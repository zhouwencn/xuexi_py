import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent
from dotenv import load_dotenv
load_dotenv()

async def main():
    client = MultiServerMCPClient(
        {
            "math": {
                "transport": "stdio",  # Local subprocess communication: 进程间通信技术
                "command": "python",
                # Absolute path to your math_server.py file
                "args": ["C:\\Users\\53409\\PycharmProjects\\langchain-demo\\mcp_test\\mcp_stdio.py"],
            },
            "weather": {
                "transport": "http",  # HTTP-based remote server
                # Ensure you start your weather server on port 8000
                "url": "http://localhost:8000/mcp",
            }
        }
    )

    tools = await client.get_tools()
    for tool in tools:
        print(f"Tool: {tool}")
    agent = create_agent(
        "deepseek-chat",
        tools
    )
    math_response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "计算 (3 + 5) x 12"}]}
    )
    weather_response = await agent.ainvoke(
        {"messages": [{"role": "user", "content": "查询 西安 的天气"}]}
    )
    print(math_response)
    print("="*50)
    print(weather_response)

if __name__ == "__main__":
    asyncio.run(main())