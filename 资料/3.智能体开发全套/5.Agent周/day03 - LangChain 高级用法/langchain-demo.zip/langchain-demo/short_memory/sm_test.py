from dataclasses import dataclass
from typing import Generic

from langchain.agents import create_agent, AgentState
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from dotenv import load_dotenv
from langgraph.prebuilt import ToolRuntime

load_dotenv()




# 继承 AgentState
class CustomAgentState(AgentState):
    user_id: str
    preferences: dict

@tool
def get_user_info(runtime: ToolRuntime[CustomAgentState]):
    """ 获取用户信息 """
    print(f"user_id: {runtime.state['user_id']}")
    return {"user_id": "user_123"}


agent = create_agent(
    "deepseek-chat",
    tools=[get_user_info],
    state_schema=CustomAgentState, # 声明短期记忆中保存什么样的数据模型
    checkpointer=InMemorySaver(),
)

# Custom state can be passed in invoke； 整个 input 全是 短期记忆中的数据。
result = agent.invoke(
    input={
        "messages": [{"role": "user", "content": "当前用户id是多少？"}],
        "user_id": "user_123",
        "preferences": {"theme": "dark"}
    },
    config={"configurable": {"thread_id": "1"}})

print(f"result: {result}")