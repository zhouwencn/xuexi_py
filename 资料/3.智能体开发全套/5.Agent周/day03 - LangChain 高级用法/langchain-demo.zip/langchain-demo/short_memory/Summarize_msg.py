from langchain.agents import create_agent
from langchain.agents.middleware import SummarizationMiddleware
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from dotenv import load_dotenv

load_dotenv()

checkpointer = InMemorySaver()


# 将中间件添加到Agent
agent = create_agent(
    model="deepseek-chat",
    tools=[],
    middleware=[
        SummarizationMiddleware(
            model="deepseek-chat",
            trigger=[
                ("tokens", 4000), # token数达到4k时触发
                ("messages", 4) # 或消息数达到 4条时触发
            ],
            keep=("messages", 4), # 摘要后保留最近 4 条消息
        )
    ],
    checkpointer=checkpointer,
)

config: RunnableConfig = {"configurable": {"thread_id": "1"}}
resp = agent.invoke({"messages": "你好，我是 雷丰阳"}, config)
resp = agent.invoke({"messages": "写一个关于猫的五言律诗"}, config)
resp = agent.invoke({"messages": "再写一个关于狗的五言律诗"}, config)
resp = agent.invoke({"messages": "再写一个关于老虎的五言律诗"}, config)
resp = agent.invoke({"messages": "再写一个关于大象的五言律诗"}, config)
final_response = agent.invoke({"messages": "我是谁？"}, config)

final_response["messages"][-1].pretty_print()