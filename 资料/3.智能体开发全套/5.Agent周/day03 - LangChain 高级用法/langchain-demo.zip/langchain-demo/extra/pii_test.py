from langchain.agents import create_agent
from langchain.agents.middleware import PIIMiddleware
from dotenv import load_dotenv
load_dotenv()

agent = create_agent(
    model="deepseek-chat",
    middleware=[
        # Redact emails in user input before sending to model
        PIIMiddleware(
            "email",
            strategy="redact",
            apply_to_input=True, # 对用户输入进行脱敏处理。发给大模型前进行脱敏
        ),
        # Mask credit cards in user input
        PIIMiddleware(
            "credit_card",
            strategy="mask",
            apply_to_input=True,
        ),
        # Block API keys - raise error if detected
        PIIMiddleware(
            "ip",
            # detector=r"sk-[a-zA-Z0-9]{32}",
            strategy="block", # 阻止API密钥被发送到模型； 默认会报错
            apply_to_input=True,
        ),
    ],
)

# When user provides PII, it will be handled according to the strategy
result = agent.invoke({
    "messages": [{"role": "user",
                  "content":
        "我的邮箱是 john.doe@example.com，信用卡号是 5105-1051-0510-5100，"
                                             }]})

print(f"☀️Result:  {result['messages'][-1].content}")
