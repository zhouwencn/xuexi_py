from langchain.agents import create_agent
from langchain.agents.middleware import (
    AgentMiddleware,
    AgentState
)
from langgraph.runtime import Runtime
from typing import Any, Callable
from dotenv import load_dotenv
load_dotenv()


class LoggingMiddleware(AgentMiddleware):
    def before_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        print(f"☀️About to call model with {len(state['messages'])} messages")
        return None

    def after_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        print(f"☀️Model returned: {state['messages'][-1].content}")
        return None

    async def abefore_model(
        self, state: AgentState, runtime: Runtime
    ) -> dict[str, Any] | None:
        # Async version of before_model
        return None

    async def aafter_model(
        self, state: AgentState, runtime: Runtime
    ) -> dict[str, Any] | None:
        # Async version of after_model
        print(f"Model returned: {state['messages'][-1].content}")
        return None


agent = create_agent(
    model="deepseek-chat",
    middleware=[LoggingMiddleware()]
)

resp =agent.invoke({
    "messages": [{"role": "user", "content": "你好"}],
    "user_preferences": {"style": "technical", "verbosity": "detailed"},
},config={"configurable": {"thread_id": "my_123"}})
print(resp)