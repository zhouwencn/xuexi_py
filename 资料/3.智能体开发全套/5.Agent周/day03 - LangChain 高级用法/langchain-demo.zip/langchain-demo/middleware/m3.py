from langchain.agents import create_agent
from langchain.messages import HumanMessage
from langchain.agents.middleware import AgentState, before_model, after_model, hook_config
from typing_extensions import NotRequired
from typing import Any
from langgraph.runtime import Runtime
from dotenv import load_dotenv
load_dotenv()


# 继承：AgentState
class CustomState(AgentState):
    model_call_count: NotRequired[int]
    user_id: NotRequired[str]



# end：代表结束
@before_model(state_schema=CustomState, can_jump_to=["end"])
# @hook_config(can_jump_to=["end"])
def check_call_limit(state: CustomState, runtime: Runtime) -> dict[str, Any] | None:
    count = state.get("model_call_count", 0)
    print(f"☀️Model call count: {count}")
    if count > 10:
        return {"jump_to": "end"}
    return None


@after_model(state_schema=CustomState)
def increment_counter(state: CustomState, runtime: Runtime) -> dict[str, Any] | None:
    return {"model_call_count": state.get("model_call_count", 0) + 1}


agent = create_agent(
    model="deepseek-chat",
    state_schema=CustomState,
    middleware=[check_call_limit, increment_counter],
    tools=[],
)

# 自定义 state 值，并执行
result = agent.invoke({
    "messages": [HumanMessage("Hello")],
    "model_call_count": 13,
    "user_id": "user-123",
})
print(f"☀️Result:  {result['messages'][-1].content}")