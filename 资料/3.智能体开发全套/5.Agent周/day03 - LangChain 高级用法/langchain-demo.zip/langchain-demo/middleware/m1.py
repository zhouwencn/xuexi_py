from langchain.agents.middleware import (
    before_model,
    wrap_model_call,
    AgentState,
    ModelRequest,
    ModelResponse,
)
from langchain.agents import create_agent
from langgraph.runtime import Runtime
from typing import Any, Callable
from dotenv import load_dotenv
load_dotenv()


@before_model
def log_before_model(state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
    print(f"☀️About to call model with {len(state['messages'])} messages")
    return None

@wrap_model_call
def retry_model(
    request: ModelRequest,
    handler: Callable[[ModelRequest], ModelResponse],
) -> ModelResponse:

    # 重试
    for attempt in range(3):
        try:
            print(f"☀️Model call attempt {attempt + 1}/3")
            # 放行：调用模型
            return handler(request)
        except Exception as e:
            if attempt == 2:
                raise
            print(f"Retry {attempt + 1}/3 after error: {e}")

agent = create_agent(
    model="deepseek-chat",
    middleware=[log_before_model, retry_model]
)

resp = agent.invoke({
    "messages": [{"role": "user", "content": "你好"}],
})

print(resp)